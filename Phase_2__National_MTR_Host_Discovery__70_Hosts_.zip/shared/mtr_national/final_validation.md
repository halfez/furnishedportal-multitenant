# MTR Leads Database — Final Validation Report
**Generated:** 2026-04-30  
**Phase:** Phase 2 National Discovery Complete

---

## ✅ Row Count Validation

| Segment | Expected | Actual | Status |
|---------|----------|--------|--------|
| Phase 1 Texas hosts | 30 | 30 | ✅ PASS |
| Phase 2 National hosts | 70 | 70 | ✅ PASS |
| **Total mtr_leads rows** | **100** | **100** | **✅ PASS** |

---

## ✅ National Market Coverage (26 Markets)

| Market | Host Count | Status |
|--------|-----------|--------|
| Atlanta | 3 | ✅ |
| Baltimore | 2 | ✅ |
| Boston | 1 | ✅ |
| Charlotte | 3 | ✅ |
| Chicago | 3 | ✅ |
| Columbus | 3 | ✅ |
| Denver | 3 | ✅ |
| Indianapolis | 3 | ✅ |
| Kansas City | 3 | ✅ |
| Los Angeles | 3 | ✅ |
| Miami | 3 | ✅ |
| Minneapolis | 3 | ✅ |
| Nashville | 3 | ✅ |
| New Orleans | 3 | ✅ |
| New York City | 2 | ✅ |
| Orlando | 3 | ✅ |
| Philadelphia | 1 | ✅ |
| Phoenix | 3 | ✅ |
| Pittsburgh | 1 | ✅ |
| Portland | 3 | ✅ |
| San Diego | 3 | ✅ |
| San Francisco | 3 | ✅ |
| Seattle | 3 | ✅ |
| St. Louis | 3 | ✅ |
| Tampa | 3 | ✅ |
| Washington DC | 3 | ✅ |
| **TOTAL** | **70** | **✅** |

---

## ✅ Website Type Distribution (National Hosts)

| Website Type | Count | % |
|-------------|-------|---|
| basic_site | 53 | 53% |
| full_portal | 35 | 35% |
| landing_page | 8 | 8% |
| none | 4 | 4% |

All values are valid per schema constraint: `none`, `landing_page`, `basic_site`, `full_portal` ✅

---

## ✅ Score Column Validation

| Score Column | Min | Max | Constraint | Status |
|-------------|-----|-----|-----------|--------|
| diversity_value_score | 10 | 40 | 0–40 | ✅ PASS |
| articulation_score | 5 | 30 | 0–30 | ✅ PASS |
| sub_wedge_score | 5 | 28 | 0–30 | ✅ PASS |
| research_value_score | 45 | 94 | 0–100 | ✅ PASS |

---

## ✅ JSONB Field Validation

| Field | Valid Rows | Total Rows | Status |
|-------|-----------|-----------|--------|
| sub_wedge_signals | 100 | 100 | ✅ PASS |
| current_tech_stack | 100 | 100 | ✅ PASS |
| listing_urls | 100 | 100 | ✅ PASS |

---

## ✅ Sub-Wedge Signal Analysis

### Phase 2 National Hosts (70 hosts, boolean format)
| Signal | Count | % |
|--------|-------|---|
| tool_fragmentation | 45 | 64% |
| corporate_credibility_loss | 14 | 20% |
| airbnb_refugee | 5 | 7% |

### Phase 1 Texas Hosts (30 hosts, nested flag format)
| Signal | Count | % |
|--------|-------|---|
| tool_fragmentation | 13 | 43% |
| credibility_loss | 26 | 87% |
| airbnb_refugee | 5 | 17% |

---

## ✅ Score Statistics (Phase 2 National)

| Metric | Value |
|--------|-------|
| Average research_value_score | 67.8 |
| Average diversity_value_score | 29.2 |
| Average articulation_score | 23.9 |
| Average sub_wedge_score | 14.7 |

---

## ✅ Top 10 Highest-Scoring National Hosts

| Host | Market | Score | Website Type |
|------|--------|-------|-------------|
| DC Digs Team | Washington DC | 94 | basic_site |
| Anne Beck | New Orleans | 87 | basic_site |
| Jeff Copeland | Tampa | 85 | basic_site |
| Jesse Lear | Columbus | 85 | basic_site |
| Autumn Thomas | Kansas City | 85 | basic_site |
| Kama Cicero | Boston | 85 | basic_site |
| L2 Accommodations Team | Baltimore | 78 | basic_site |
| Capitol Hill Stay Team | Washington DC | 77 | basic_site |
| Lorna Arnold | Seattle | 75 | basic_site |
| Adam Knight | Seattle | 75 | full_portal |

---

## Summary

**All validation checks passed.** The mtr_leads table contains exactly 100 rows:
- **30 Phase 1 Texas hosts** (Austin, Dallas, San Antonio, Houston)
- **70 Phase 2 National hosts** across 26 US markets (excluding Texas)

The database is ready for Phase 3 analysis and outreach workflows.
