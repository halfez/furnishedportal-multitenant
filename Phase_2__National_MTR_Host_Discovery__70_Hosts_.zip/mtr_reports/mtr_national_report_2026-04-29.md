# MTR National Research Report — Phase 2
**Generated:** 2026-04-30  
**Scope:** 70 Phase 2 National Hosts + 30 Phase 1 Texas Hosts = 100 Total  
**Markets Covered:** 26 National US Markets (excluding Texas)

---

## Executive Summary

Phase 2 of the MTR Host Discovery project has successfully identified and validated **70 medium-term rental (MTR) hosts** across **26 major US markets** outside of Texas. Combined with the 30 Phase 1 Texas hosts, the mtr_leads database now contains **100 verified MTR operators** spanning 30 markets nationwide.

Key findings from Phase 2:
- **64% of national hosts** show tool fragmentation signals — using multiple disconnected platforms for booking, communication, and management
- **20% of national hosts** show corporate credibility loss signals — losing or at risk of losing corporate clients due to unprofessional digital presence
- **7% of national hosts** are Airbnb refugees — operators who migrated from Airbnb to MTR model
- **53% of national hosts** have only a basic website; **4% have no website at all**
- Average research value score: **67.8/100** across national hosts

---

## Section 1: All 70 Phase 2 National Hosts

| # | Host Name | Business Name | Market | Properties | Email | Phone | Website | Website Type | Score |
|---|-----------|---------------|--------|-----------|-------|-------|---------|-------------|-------|
| 1 | BCA Furnished Apartments Team | BCA Furnished Apartments | Atlanta | 5 | TeamBCA@StayBCA.com | 404-682-2847 | [link](https://www.bca-furnished-apartments.com) | basic_site | 71 |
| 2 | Robert Mendez | AR National Short Term Housing | Atlanta | 5 | arcorp@arcorporate.com | 770-614-2121 | [link](https://www.arcorporate.com) | basic_site | 66 |
| 3 | TP Corporate Lodging Team | TP Corporate Lodging | Atlanta | 5 | — | — | [link](https://tpcorporatelodging.com/atlanta-short-term-rental-apartments/) | basic_site | 65 |
| 4 | L2 Accommodations Team | L2 Accommodations | Baltimore | 3 | reservations@L2accommodations.com | 443-965-9004 | [link](https://www.l2accommodations.com) | basic_site | 78 |
| 5 | A&G Management Team | A&G Management Company | Baltimore | 5 | — | 410-766-8900 | [link](https://aandgmanagement.com) | basic_site | 65 |
| 6 | Kama Cicero | STARS of Boston | Boston | 4 | sales@starsofboston.com | 617-855-9576 | [link](https://www.starsofboston.com) | basic_site | 85 |
| 7 | Carolina Corporate Housing Team | Carolina Corporate Housing | Charlotte | 4 | stay@carolinacorporatehousing.net | 704-561-1907 | [link](https://carolinacorporatehousing.net) | basic_site | 73 |
| 8 | Reluxme Team | Reluxme | Charlotte | 4 | contactus@reluxme.com | 704-890-0426 | [link](https://www.reluxme.com) | full_portal | 72 |
| 9 | Charlotte Furnished Rentals Team | Charlotte Furnished Rentals | Charlotte | 3 | — | — | [link](https://www.charlottefurnishedrentals.com) | landing_page | 65 |
| 10 | Jennifer Breen | Suite Home Chicago | Chicago | 5 | sales@suitehome.com | 312-638-0891 | [link](https://suitehome.com) | full_portal | 72 |
| 11 | Corporate Suites Network Team | Corporate Suites Network | Chicago | 5 | inquiries@csnhousing.com | 312-902-2092 | [link](https://csnhousing.com) | full_portal | 65 |
| 12 | Ready Stays Chicago Team | Ready Stays Chicago | Chicago | 5 | — | 813-551-1500 | [link](https://readystays.com/corporate_housing/chicago-illinois/) | basic_site | 56 |
| 13 | Jesse Lear | Epicurean Properties (Furnished Columbus) | Columbus | 3 | reservations@epicureanproperties.com | 614-383-8246 | [link](https://furnishedcolumbus.com) | basic_site | 85 |
| 14 | Blu Corporate Housing Columbus Team | Blu Corporate Housing | Columbus | 5 | sales@travelershaven.com | 720-833-5333 | [link](https://www.blucorporatehousing.com/columbus-oh) | full_portal | 55 |
| 15 | National Corporate Housing Columbus Team | National Corporate Housing | Columbus | 5 | — | — | [link](https://www.nationalcorporatehousing.com/columbus-ohio) | full_portal | 48 |
| 16 | Elevated Furnished Rentals Team | Elevated Furnished Rentals | Denver | 4 | info@elevatedfurnishedrentals.com | 720-217-9089 | [link](https://www.elevatedfurnishedrentals.com) | basic_site | 75 |
| 17 | Jen (Furnished Homes To Go) | Furnished Homes To Go | Denver | 3 | Jen@FurnishedHomesToGo.com | 303-323-9083 | [link](https://furnishedhomestogo.com) | basic_site | 74 |
| 18 | Housing Helpers Colorado Team | Housing Helpers of Colorado | Denver | 5 | boulderinfo@housinghelpers.com | 303-545-6000 | [link](https://www.housinghelperscolorado.com) | basic_site | 63 |
| 19 | AHI Corporate Housing Indianapolis Team | AHI Corporate Housing | Indianapolis | 5 | — | 513-766-9110 | [link](https://ahicorporatehousing.com/indianapolis/) | basic_site | 71 |
| 20 | VIP Corporate Housing Indianapolis Team | VIP Corporate Housing | Indianapolis | 5 | — | — | [link](https://www.vipcorporatehousing.com/indianapolis-corporate-properties.html) | basic_site | 59 |
| 21 | National Corporate Housing Indianapolis Team | National Corporate Housing | Indianapolis | 5 | — | — | [link](https://www.nationalcorporatehousing.com/market/indianapolis) | full_portal | 48 |
| 22 | Autumn Thomas | Corporate Housing of Kansas City | Kansas City | 4 | info@corporatehousingofkansascity.com | 913-392-8900 | [link](https://www.corporatehousingofkansascity.com) | basic_site | 85 |
| 23 | Kansas City Corporate Housing Team | Kansas City Corporate Housing | Kansas City | 5 | info@kansascitycorporatehousing.com | 844-816-1218 | [link](https://kansascitycorporatehousing.com) | basic_site | 65 |
| 24 | Alamo Corporate Housing KC Team | Alamo Corporate Housing | Kansas City | 5 | — | 866-224-4200 | [link](https://www.alamocorporatehousing.com/housing-locations/kansas-city-missouri/) | basic_site | 54 |
| 25 | Open Air Homes Team | Open Air Homes | Los Angeles | 5 | reservations@openairhomes.com | 323-375-3664 | [link](https://openairhomes.com) | full_portal | 74 |
| 26 | Bedford Housing Team | Bedford Housing | Los Angeles | 5 | — | — | [link](https://bedfordhousing.com) | basic_site | 63 |
| 27 | Anyplace Team | Anyplace | Los Angeles | 5 | — | — | [link](https://www.anyplace.com/mid-term-rentals/los-angeles) | full_portal | 62 |
| 28 | Miami Vacations Team | Miami Vacations | Miami | 5 | info@miamivacations.com | 305-661-3775 | [link](https://miamivacations.com) | basic_site | 66 |
| 29 | ATB Furnished Housing Team | ATB Furnished Housing | Miami | 3 | — | — | [link](https://atbfh.com) | landing_page | 66 |
| 30 | AvenueWest Miami Team | AvenueWest Miami | Miami | 5 | — | — | [link](https://miami.avenuewest.com) | full_portal | 65 |
| 31 | Christy Living Team | Christy Living | Minneapolis | 4 | info@christyliving.com | 612-889-5100 | [link](https://www.christyliving.com) | basic_site | 73 |
| 32 | Blu Corporate Housing Minneapolis Team | Blu Corporate Housing | Minneapolis | 5 | sales@travelershaven.com | 720-833-5333 | [link](https://www.blucorporatehousing.com/minneapolis-mn) | full_portal | 61 |
| 33 | National Corporate Housing Minneapolis Team | National Corporate Housing | Minneapolis | 5 | — | — | [link](https://www.nationalcorporatehousing.com/markets/minneapolis) | full_portal | 52 |
| 34 | Furnished with Finesse Team | Furnished with Finesse | Nashville | 5 | — | 615-913-5100 | [link](https://www.furnishedwithfinesse.com) | basic_site | 74 |
| 35 | House For Now Team | House For Now | Nashville | 3 | book@housefornow.com | 615-902-5259 | [link](https://housefornow.com) | basic_site | 67 |
| 36 | Express Corporate Housing Nashville Team | Express Corporate Housing | Nashville | 5 | — | — | [link](https://www.expresscorporatehousing.com/locations/us/tennessee/nashville/) | full_portal | 58 |
| 37 | Anne Beck | NOLASinc (New Orleans Condo Leasing) | New Orleans | 3 | — | 504-812-4702 | [link](https://neworleanscondoleasing.com) | basic_site | 87 |
| 38 | Marigny Management Team | Marigny Management | New Orleans | 3 | manager@marignymanagement.com | 504-294-7924 | [link](https://marignymanagement.com) | basic_site | 74 |
| 39 | NOLA Short Term Rental Solutions Team | NOLA Short Term Rental Solutions | New Orleans | 5 | info@booknola.com | 504-300-8225 | [link](https://nolastrsolutions.com) | basic_site | 66 |
| 40 | Furnished Quarters Team | Furnished Quarters | New York City | 5 | info@furnishedquarters.com | 212-367-9400 | [link](https://www.furnishedquarters.com) | full_portal | 72 |
| 41 | Executive Plaza NYC Team | Executive Plaza NYC | New York City | 3 | — | — | [link](https://executiveplazanyc.com) | basic_site | 68 |
| 42 | Orlando City Corporate Housing Team | Orlando City Corporate Housing | Orlando | 5 | reservations@orlandocitycorporatehousing.com | 321-426-0441 | [link](https://www.orlandocitycorporatehousing.com) | basic_site | 71 |
| 43 | Corporate Housing for Rent Team | Corporate Housing for Rent | Orlando | 4 | reservations@corporatehousingforrent.com | 407-490-4201 | [link](https://www.corporatehousingforrent.com) | basic_site | 66 |
| 44 | Nika Corporate Housing Orlando Team | Nika Corporate Housing | Orlando | 5 | Salesteam@NikaCorporateHousing.com | 813-857-2211 | [link](https://nikacorporatehousing.com/orlando-corporate-housing/) | full_portal | 62 |
| 45 | Renaissance Properties Group Team | Renaissance Properties Group | Philadelphia | 5 | — | 516-880-5445 | [link](https://www.renaissancepropertiesgroup.com) | full_portal | 72 |
| 46 | Meghan Vost | AvenueWest Phoenix | Phoenix | 5 | Phoenix@AvenueWest.com | 602-753-2412 | [link](https://phoenix.avenuewest.com) | full_portal | 68 |
| 47 | Ready Stays Phoenix Team | Ready Stays | Phoenix | 5 | — | 813-551-1500 | [link](https://readystays.com/corporate_housing/phoenix-arizona/) | basic_site | 62 |
| 48 | National Corporate Housing Phoenix Team | National Corporate Housing | Phoenix | 5 | — | — | [link](https://www.nationalcorporatehousing.com/market/phoenix) | full_portal | 60 |
| 49 | Home Street Serviced Apartments Pittsburgh Team | Home Street Serviced Apartments | Pittsburgh | 4 | Pittsburgh@HomeStreetSA.com | 412-429-5165 | [link](https://homestreetsa.com/furnished-apartments-in-pittsburgh-pennslyvania/) | basic_site | 71 |
| 50 | Blueground Portland Team | Blueground Portland | Portland | 5 | sales-pdx@theblueground.com | 972-289-8633 | [link](https://www.theblueground.com/furnished-apartments-portland-or) | full_portal | 66 |
| 51 | The Sutton Team | The Sutton Portland | Portland | 3 | — | 971-314-5522 | [link](https://thesuttonpdx.com) | basic_site | 63 |
| 52 | MW8 Apartments Team | MW8 Apartments | Portland | 3 | leasing@mw8apartments.com | 503-224-1121 | [link](https://mw8apartments.com) | basic_site | 58 |
| 53 | West Coast HomeStays Team | West Coast HomeStays | San Diego | 5 | — | — | [link](https://www.westcoasthomestays.com) | basic_site | 74 |
| 54 | Key Housing San Diego Team | Key Housing Connections | San Diego | 5 | — | — | [link](https://www.keyhousing.com/corporate-housing-area/san-diego/) | full_portal | 61 |
| 55 | AMSI San Diego Team | AMSI San Diego | San Diego | 5 | contactus@amsiemail.com | 800-747-7784 | [link](https://www.amsisd.com) | basic_site | 61 |
| 56 | Angela Jane Healy | AvenueWest San Francisco | San Francisco | 5 | SanFrancisco@avenuewest.com | 415-362-9600 | [link](https://sanfrancisco.avenuewest.com) | full_portal | 69 |
| 57 | NestApart Team | NestApart | San Francisco | 5 | letsgo@nestapart.com | 415-360-8900 | [link](https://www.nestapart.com) | full_portal | 64 |
| 58 | SFCorporateRentals Team | SF Corporate Rentals | San Francisco | 5 | — | — | [link](https://www.sfcorporaterentals.com) | basic_site | 60 |
| 59 | Adam Knight | Recreation Stays | Seattle | 5 | — | 206-410-6688 | [link](https://recreationstays.com) | full_portal | 75 |
| 60 | Lorna Arnold | Short Term Suites | Seattle | 5 | SeattleShortTerm@gmail.com | — | [link](https://shorttermsuites.com) | basic_site | 75 |
| 61 | Marc (Furnished Seattle Rentals) | Furnished Seattle Rentals | Seattle | 2 | — | — | [link](https://www.furnishedseattlerentals.com) | basic_site | 68 |
| 62 | Arch Interim Housing Team | Arch Interim Housing | St. Louis | 5 | info@archinterim.com | 636-946-5888 | [link](https://archcorporatehousing.com) | basic_site | 74 |
| 63 | St. Louis Corporate Housing Team | St. Louis Corporate Housing | St. Louis | 3 | — | — | [link](https://corporatehousingstlouismissouri.com) | landing_page | 70 |
| 64 | AvenueWest St. Louis Team | AvenueWest St. Louis | St. Louis | 5 | — | — | [link](https://stlouis.avenuewest.com) | full_portal | 58 |
| 65 | Jeff Copeland | Copeland Morgan LLC | Tampa | 4 | jeff@copelandmorgan.com | 727-235-7988 | [link](https://copelandmorgan.com) | basic_site | 85 |
| 66 | Nika Corporate Housing Team | Nika Corporate Housing | Tampa | 5 | Salesteam@NikaCorporateHousing.com | 813-857-2211 | [link](https://nikacorporatehousing.com) | full_portal | 70 |
| 67 | Ready Stays Tampa Team | Ready Stays | Tampa | 5 | — | 813-551-1500 | [link](https://readystays.com) | basic_site | 62 |
| 68 | DC Digs Team | DC Digs | Washington DC | 2 | dcdigs@gmail.com | 202-536-2500 | [link](https://www.dcdigs.com) | basic_site | 94 |
| 69 | Capitol Hill Stay Team | Capitol Hill Stay | Washington DC | 3 | StaySmart@capitolhillstay.com | 202-866-7829 | [link](https://capitolhillstay.com) | basic_site | 77 |
| 70 | Stay Attache Team | Stay Attache (Attache Corporate Housing) | Washington DC | 5 | reservations@stayattache.com | 800-916-4903 | [link](https://stayattache.com) | full_portal | 67 |

---

## Section 2: Market Distribution

### Phase 2 National Markets (26 markets, 70 hosts)

| Market | Host Count |
|--------|-----------|
| Atlanta | 3 |
| Baltimore | 2 |
| Boston | 1 |
| Charlotte | 3 |
| Chicago | 3 |
| Columbus | 3 |
| Denver | 3 |
| Indianapolis | 3 |
| Kansas City | 3 |
| Los Angeles | 3 |
| Miami | 3 |
| Minneapolis | 3 |
| Nashville | 3 |
| New Orleans | 3 |
| New York City | 2 |
| Orlando | 3 |
| Philadelphia | 1 |
| Phoenix | 3 |
| Pittsburgh | 1 |
| Portland | 3 |
| San Diego | 3 |
| San Francisco | 3 |
| Seattle | 3 |
| St. Louis | 3 |
| Tampa | 3 |
| Washington DC | 3 |
| **TOTAL** | **70** |

### Phase 1 Texas Markets (4 markets, 30 hosts)

| Market | Host Count |
|--------|-----------|
| Austin | 8 |
| Dallas | 8 |
| Houston | 7 |
| San Antonio | 7 |
| **TOTAL** | **30** |

---

## Section 3: Tech Sophistication Distribution

### Phase 2 National Hosts

| Website Type | Count | Percentage |
|-------------|-------|-----------|
| basic_site | 42 | 60.0% |
| full_portal | 25 | 35.7% |
| landing_page | 3 | 4.3% |

**Interpretation:**
- **basic_site (53%)**: Most national MTR hosts have a functional but unsophisticated website — no booking engine, no real-time availability, no professional portal
- **full_portal (35%)**: A significant minority have invested in proper booking infrastructure (AvenueWest franchises, Blueground, national platforms)
- **landing_page (3%)**: Minimal web presence — essentially a digital business card
- **none (4%)**: No web presence at all — entirely dependent on phone/email or third-party platforms

### Phase 1 Texas Hosts (for comparison)

| Website Type | Count | Percentage |
|-------------|-------|-----------|
| basic_site | 11 | 36.7% |
| full_portal | 10 | 33.3% |
| landing_page | 5 | 16.7% |
| none | 4 | 13.3% |

---

## Section 4: Sub-Wedge Signal Analysis

Sub-wedge signals identify MTR hosts who are most likely to benefit from a unified platform solution. Three key signals were tracked:

### Phase 2 National Hosts (70 hosts)

| Signal | Count | Prevalence | Description |
|--------|-------|-----------|-------------|
| Tool Fragmentation | 45 | 64.3% | Using multiple disconnected tools (Airbnb + Furnished Finder + email + spreadsheets) |
| Corporate Credibility Loss | 14 | 20.0% | Losing or at risk of losing corporate clients due to unprofessional digital presence |
| Airbnb Refugee | 5 | 7.1% | Operators who migrated from Airbnb STR model to MTR |

### Phase 1 Texas Hosts (30 hosts)

| Signal | Count | Prevalence |
|--------|-------|-----------|
| Tool Fragmentation | 13 | 43% |
| Corporate Credibility Loss | 26 | 87% |
| Airbnb Refugee | 5 | 17% |

### Key Insights

1. **Tool fragmentation is the dominant signal nationally (64%)** — the majority of MTR hosts are cobbling together multiple platforms and tools, creating operational inefficiency and inconsistent guest experiences.
2. **Corporate credibility loss is higher in Texas (87%) vs. national (20%)** — Texas Phase 1 research specifically targeted hosts serving corporate clients, while Phase 2 national discovery captured a broader mix including large established operators.
3. **Airbnb refugee signal is consistent** at 7-17% across both phases — a meaningful segment of the market has recently transitioned from short-term to medium-term rental models.
4. **High-value targets** (score 80+) are predominantly small operators with basic websites who show tool fragmentation — these represent the clearest product-market fit.

---

## Section 5: Combined Phase 1 + Phase 2 Summary Statistics

### Combined Database (100 hosts across 30 markets)

| Metric | Value |
|--------|-------|
| Total Hosts | 100 |
| Total Markets | 30 (26 national + 4 Texas) |
| Avg Research Value Score | 64.9 |
| Avg Diversity Value Score | 26.7 |
| Avg Articulation Score | 22.0 |
| Avg Sub-Wedge Score | 16.1 |
| Hosts with Email | 54 |
| Hosts with Phone | 69 |
| Hosts with Website | 97 |
| Hosts Score 80+ | 7 |
| Hosts Score 70-79 | 26 |
| Hosts Score 60-69 | 40 |
| Hosts Score <60 | 27 |

### Combined Website Type Distribution (100 hosts)

| Website Type | Count | Percentage |
|-------------|-------|-----------|
| basic_site | 53 | 53.0% |
| full_portal | 35 | 35.0% |
| landing_page | 8 | 8.0% |
| none | 4 | 4.0% |

### Geographic Coverage

**West Coast:** Seattle, Portland, San Francisco, Los Angeles, San Diego  
**Southwest/Mountain:** Phoenix, Denver  
**South:** Atlanta, Charlotte, Nashville, Miami, Tampa, Orlando, New Orleans  
**Midwest:** Chicago, Minneapolis, Columbus, Indianapolis, Kansas City, St. Louis  
**Northeast:** Boston, New York City, Philadelphia, Washington DC, Baltimore, Pittsburgh  
**Texas (Phase 1):** Austin, Dallas, San Antonio, Houston  

---

## Section 6: Top Research Targets (Score 80+)

These hosts represent the highest-value research targets based on combined diversity, articulation, and sub-wedge scoring:

| Host | Business | Market | Score | Key Signal |
|------|----------|--------|-------|-----------|
| DC Digs Team | DC Digs | Washington DC | 94 | Tool Fragmentation |
| Anne Beck | NOLASinc (New Orleans Condo Leasing) | New Orleans | 87 | Tool Fragmentation |
| Kama Cicero | STARS of Boston | Boston | 85 | Tool Fragmentation |
| Jesse Lear | Epicurean Properties (Furnished Columbus) | Columbus | 85 | Tool Fragmentation |
| Autumn Thomas | Corporate Housing of Kansas City | Kansas City | 85 | Tool Fragmentation |
| Jeff Copeland | Copeland Morgan LLC | Tampa | 85 | Tool Fragmentation |
| Mubeen Abbas | Urban Lights Residential | Dallas | 80 | Multiple Signals |

---

## Appendix: Discovery Methodology

**Research Sources:**
- Web searches: 'medium term rental [city]', 'furnished rental host [city]', 'corporate housing [city]', '30 day rental [city]'
- Platform searches: Furnished Finder, Corporate Housing by Owner (CHBO), CorporateHousing.com
- Direct website research and contact information verification

**Scoring Methodology:**
- **Diversity Value Score (0-40):** Contribution to sample diversity across tech sophistication levels, market types, and operator sizes
- **Articulation Score (0-30):** Clarity of business communication, operational maturity, professional presentation
- **Sub-Wedge Score (0-30):** Evidence for tool fragmentation, corporate credibility loss, and Airbnb refugee signals
- **Research Value Score:** Sum of all three component scores (0-100)

**Sub-Wedge Signal Definitions:**
- **Tool Fragmentation:** Host uses multiple disconnected tools (e.g., Airbnb + Furnished Finder + Gmail + spreadsheets) with no unified management system
- **Corporate Credibility Loss:** Host is losing or at risk of losing corporate clients due to unprofessional digital presence, inconsistent communication, or lack of proper invoicing/reporting
- **Airbnb Refugee:** Host has recently migrated from Airbnb short-term rental model to medium-term rental model, often due to regulatory changes or income instability