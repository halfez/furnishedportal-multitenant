-- Migration: Sales-focused → Customer Validation Research
-- Drop old sales-focused columns
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS fit_score;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS intent_score;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS engagement_score;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS timing_score;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS pain_signals;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS outreach_status;
ALTER TABLE mtr_leads DROP COLUMN IF EXISTS lead_score;

-- Rename to research-oriented naming
ALTER TABLE mtr_leads DROP CONSTRAINT IF EXISTS mtr_leads_website_type_check;
ALTER TABLE mtr_leads ADD CONSTRAINT mtr_leads_website_type_check 
  CHECK (website_type IN ('none', 'landing_page', 'basic_site', 'full_portal'));

-- Add research-value scoring columns
ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS diversity_value_score INTEGER DEFAULT 0 CHECK (diversity_value_score BETWEEN 0 AND 40);
ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS articulation_score INTEGER DEFAULT 0 CHECK (articulation_score BETWEEN 0 AND 30);
ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS sub_wedge_score INTEGER DEFAULT 0 CHECK (sub_wedge_score BETWEEN 0 AND 30);
ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS research_value_score INTEGER DEFAULT 0 CHECK (research_value_score BETWEEN 0 AND 100);

-- Sub-wedge signal tracking
ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS sub_wedge_signals JSONB DEFAULT '{}'::jsonb;
-- Structure: {"tool_fragmentation": {"flag": bool, "evidence": "..."}, "credibility_loss": {"flag": bool, "evidence": "..."}, "airbnb_refugee": {"flag": bool, "evidence": "..."}}

ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS current_tech_stack JSONB DEFAULT '[]'::jsonb;
-- Array of tools mentioned: ["Guesty", "spreadsheets", "email", etc.]

ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS airbnb_history TEXT;
-- Did they mention migrating from Airbnb? Why?

ALTER TABLE mtr_leads ADD COLUMN IF NOT EXISTS corporate_client_mentions TEXT;
-- Any references to corporate bookings

-- Replace old index with research-value index
DROP INDEX IF EXISTS idx_mtr_leads_score;
CREATE INDEX IF NOT EXISTS idx_mtr_leads_research_score ON mtr_leads(research_value_score DESC);
CREATE INDEX IF NOT EXISTS idx_mtr_leads_website_type ON mtr_leads(website_type);
