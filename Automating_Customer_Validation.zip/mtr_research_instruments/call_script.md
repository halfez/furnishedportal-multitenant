# MTR Host Interview Call Script (15 Minutes)

**Framework:** SPIN Selling (Situation → Problem → Implication → Need-Payoff)  
**Duration:** 15 minutes  
**Format:** Phone or Zoom  
**Goal:** Validate sub-wedges + capture quantified pain + assess WTP

---

## Pre-Call Checklist

Before the call, prepare:

- [ ] Research the host (property portfolio, market, booking platforms, tech stack if visible)
- [ ] Pre-fill known context (property count, market, years in business)
- [ ] Have note-taking template open (see "Interview Notes Template" at bottom)
- [ ] Set timer reminders (5 min, 10 min, 13 min) to stay on track
- [ ] Test recording setup (if recording with permission — always ask first!)

---

## Call Structure Overview

| Phase | Duration | Focus |
|-------|----------|-------|
| **Intro** | 1 min | Set expectation, build trust |
| **Situation** | 3 min | Current state, context, workflow |
| **Problem** | 5 min | Test all 3 sub-wedges, identify acute pain |
| **Implication** | 3 min | Quantify cost (time, money, lost deals) |
| **Need-Payoff** | 3 min | What would they pay to solve it? |

---

## INTRO (1 Minute)

**Your opening (30 seconds):**

> "Hey [Name], thanks for making time! Just to set expectations — this is pure research, no sales pitch. I run a couple MTR properties in San Antonio and I've been hitting the same operational headaches over and over. I'm talking to 20-30 hosts like you to see if my pain is universal or if I'm just doing it wrong. I'll ask you about your workflow and what sucks, you'll give me the unfiltered truth, and we'll wrap in 15 minutes. Sound good?"

**Build trust (30 seconds):**

> "Before we dive in — is it cool if I take notes? I'm trying to capture exact quotes so I can see patterns across conversations. Also, everything you say stays anonymous unless you tell me otherwise."

**Permission to record (optional):**

> "One more thing — would you be okay if I record this? It helps me go back and catch things I might have missed. Totally fine if not — I'll just take notes."

**Key principle:** Be conversational, not robotic. Adapt the language to match their energy/tone.

---

## SITUATION QUESTIONS (3 Minutes)

**Goal:** Establish context. Use sparingly — you should have researched most of this already.

**Critical rule from SPIN:** Don't spend too much time here. Prospects get bored answering obvious questions. Move quickly to Problem.

---

### S1: Portfolio Overview (30 seconds)

> "Just to ground me — how many MTR properties are you running right now, and where are they located?"

**Listen for:** Portfolio size (1-2 vs. 5+ scales differently), market concentration, expansion plans.

**Note-taking prompt:** [Portfolio: X properties in Y market]

---

### S2: Booking Mix (30 seconds)

> "Where do most of your bookings come from? Airbnb, Furnished Finder, direct, corporate contracts?"

**Listen for:** Channel diversification, reliance on platforms, corporate vs. individual guests.

**Note-taking prompt:** [Booking sources: Primary = X, Secondary = Y]

---

### S3: Tech Stack (1 minute)

> "Walk me through your tech stack — what tools are you using to run the business? PMS, messaging, smart locks, cleaning, payments, whatever comes to mind."

**Listen for:** Tool count (3-5 is normal, 6+ is fragmentation), manual processes, spreadsheets, "I just use [single tool]" (green flag for fragmentation wedge).

**Note-taking prompt:** [Tech stack: 1. ___, 2. ___, 3. ___... Total count: X]

---

### S4: Workflow Anchor (1 minute)

> "Let's use your last booking as an example. Walk me through what happened from the moment you got the confirmation to the moment the guest checked in. Every step."

**Listen for:** Number of systems touched, manual copy-paste, context switching, "then I have to log into [tool]", "I manually send them..."

**Note-taking prompt:** [Workflow steps: 1. ___, 2. ___, 3. ___... Manual steps: X]

**TRANSITION TO PROBLEM:**

> "Got it. So it sounds like you're juggling [X tools/steps]. Let me dig into where this starts to get painful..."

---

## PROBLEM QUESTIONS (5 Minutes)

**Goal:** Uncover difficulties and dissatisfactions. This is where you test the 3 sub-wedges.

**Critical rule from SPIN:** Ask open-ended questions. Let them talk. The more they talk, the more they sell themselves on the pain.

---

### Sub-Wedge A: Tool Fragmentation Post-Booking (2 minutes)

**P1: General friction**

> "You mentioned you use [X, Y, Z tools]. What's the most annoying part of that workflow?"

**Listen for:** "Switching between apps," "copy-pasting info," "manually updating," "things fall through the cracks," "I forget to..."

**QUOTE CAPTURE PROMPT:** If they say something emotionally charged, pause and say: "Hold on, I want to write that down exactly. You said [repeat their quote] — is that right?"

---

**P2: Time drain**

> "How much time does all that take you per booking? Like, from confirmation to guest checked in and settled, how many minutes or hours are you spending on admin?"

**Listen for:** Time quantifiers ("30 minutes," "an hour," "half my day"). Multiply by booking volume to calculate total time cost.

**Note-taking prompt:** [Time per booking: X minutes/hours × Y bookings/month = Z hours/month]

---

**P3: Error risk**

> "Have you ever had something slip through the cracks because you were juggling all these tools? Like, forgot to send a code, double-booked, missed a message?"

**Listen for:** Specific stories. One story = pain is real. Multiple stories = pain is acute.

**QUOTE CAPTURE PROMPT:** If they tell a story, capture it verbatim. These are gold for marketing.

---

### Sub-Wedge B: Corporate Credibility Loss (1.5 minutes)

**P4: Corporate inquiry experience**

> "Do you ever get inquiries from corporate clients or travel coordinators? People booking for relocating employees, consultants, that kind of thing?"

**If YES:**

> "Tell me about the last time one of those inquiries didn't convert. What happened?"

**Listen for:** "They wanted a professional booking system," "asked for invoicing," "needed reporting," "said it looked like Airbnb," "wanted to pay via Purchase Order."

**If NO:**

> "Interesting. Do you *want* corporate bookings, or are you happy with the current mix?"

**Listen for:** "I'd love to," "tried but it didn't work," "don't know how to reach them," "they don't take me seriously."

---

**P5: Feature gaps**

> "Have any of those corporate clients asked you for features you don't have? Like, specific things they expected that you couldn't provide?"

**Listen for:** "Portal," "invoicing," "net-30 payment terms," "consolidated billing," "usage reports," "white-label experience."

**Note-taking prompt:** [Corporate feature requests: 1. ___, 2. ___, 3. ___]

---

### Sub-Wedge C: Airbnb Refugee (1.5 minutes)

**P6: Platform shift**

> "Have you shifted away from Airbnb or other STR platforms toward longer-term MTR bookings?"

**If YES:**

> "What drove that decision?"

**Listen for:** "Airbnb fees are insane," "regulation crackdown," "wanted stable income," "sick of turnover," "guests are more respectful with MTR."

**QUOTE CAPTURE PROMPT:** This is a high-emotion topic. Capture their reasoning verbatim.

---

**P7: Transition pain**

> "What's been the hardest part about making that shift from STR to MTR?"

**Listen for:** "Finding corporate tenants," "screening for 1-3 month stays," "pricing differently," "different operational cadence," "my tools are built for STR."

**Note-taking prompt:** [Airbnb → MTR transition pain: ___]

**TRANSITION TO IMPLICATION:**

> "Okay, so it sounds like the biggest pain points are [summarize top 2-3]. Let me dig into what this is actually costing you..."

---

## IMPLICATION QUESTIONS (3 Minutes)

**Goal:** Expand the perceived cost and urgency of the problem. Make the pain acute.

**Critical rule from SPIN:** This is where deals are won. Get them to articulate the full cost (time, money, opportunity, stress).

---

### I1: Time cost amplification

> "Earlier you said it takes you [X minutes/hours] per booking. How many bookings are you managing per month?"

**Do the math with them:**

> "So that's [X hours] × [Y bookings] = [Z hours per month]. What's your time worth per hour? Or, what else could you be doing with those [Z hours]?"

**Listen for:** "I could be sourcing new properties," "I could be spending time with my family," "I could be working on my other business."

**Note-taking prompt:** [Time cost: Z hours/month × $X/hour = $Y/month]

---

### I2: Money cost (lost deals)

> "You mentioned you lost that corporate booking because [reason]. How much was that deal worth?"

**If they give a number:**

> "And how often does that happen? Like, how many corporate inquiries do you get per month, and how many actually convert?"

**Do the math:**

> "So you're losing [X deals] × [$Y per deal] = [$Z per month] because of [their stated reason]."

**Listen for:** Money quantifiers. If they can't quantify, ask: "Ballpark — what's a typical corporate booking worth to you?"

**Note-taking prompt:** [Lost deal cost: X deals/month × $Y/deal = $Z/month]

---

### I3: Opportunity cost

> "If you didn't have to deal with [their stated pain], what would you do with that time or money?"

**Listen for:** Growth plans ("I'd expand to 10 properties"), lifestyle goals ("I'd actually take a vacation"), business leverage ("I'd hire someone to handle this").

**Note-taking prompt:** [Opportunity cost: ___]

---

### I4: Stress cost (qualitative)

> "How does all this make you *feel*? Like, when you're juggling [X tools] or you lose a corporate deal, what's going through your head?"

**Listen for:** Emotion words ("frustrated," "exhausted," "embarrassed," "stuck"). This is qualitative but powerful for marketing.

**QUOTE CAPTURE PROMPT:** If they use strong emotion language, capture it verbatim.

**TRANSITION TO NEED-PAYOFF:**

> "Okay, so just to recap — you're spending [X hours/month], losing [Y deals worth $Z], and it's making you feel [emotion]. Let's talk about what would need to change to fix this..."

---

## NEED-PAYOFF QUESTIONS (3 Minutes)

**Goal:** Get the prospect to articulate the value of a solution in their own words. Ask what they would pay.

**Critical rule from SPIN:** Let *them* describe the solution. Don't pitch. If you pitch before they've articulated need-payoff, you'll lose them.

---

### NP1: Ideal solution description

> "If you could wave a magic wand and fix [their #1 pain], what would that look like? What would have to be true?"

**Listen for:** Solution requirements in their own words. They're building the spec for you.

**Note-taking prompt:** [Ideal solution: ___]

---

### NP2: Impact quantification

> "If that problem went away, what would change for you? How would your business or your day-to-day be different?"

**Listen for:** "I'd save X hours," "I'd close more corporate deals," "I'd scale to X properties," "I'd actually sleep."

**Note-taking prompt:** [Impact if solved: ___]

---

### NP3: Willingness to pay

> "Let me ask you this — if there was a tool or service that eliminated [their #1 pain] and delivered [their stated impact], what would you be willing to pay per month per property?"

**If they hesitate:**

> "No right or wrong answer — I'm just trying to get a sense of what price point makes sense."

**Listen for:** Dollar amount. If they say "I don't know," give them ranges: "Would you pay $25? $50? $100?"

**Note-taking prompt:** [WTP: $X/month per property]

---

### NP4: Decision urgency

> "How urgent is this for you? Like, if I built this tomorrow, would you want it next week, or is this more of a 'nice to have in 6 months' thing?"

**Listen for:** Urgency signals ("I need this now," "yesterday," "ASAP") vs. lukewarm ("eventually," "maybe," "when I have time").

**Note-taking prompt:** [Urgency: High / Medium / Low]

---

### NP5: Competitive alternatives

> "Are you currently using anything to try to solve this, or are you just living with the pain?"

**Listen for:** Competitive solutions, workarounds, "I tried [X] but it didn't work."

**Note-taking prompt:** [Current alternatives: ___]

**WRAP-UP:**

> "This has been super helpful — I really appreciate the candor. Just to close out: if I end up building something based on this research, would you want to be a beta tester or get early access?"

**Listen for:** "Yes" = they're genuinely interested. "Maybe" = lukewarm. "No" = not a real buyer.

**Note-taking prompt:** [Beta interest: Yes / Maybe / No]

---

## CLOSING (30 Seconds)

> "Thanks again, [Name]. I'm going to synthesize all these conversations and figure out if there's a pattern worth solving. If you think of anything else after we hang up, feel free to shoot me a text or email. And if you know any other MTR hosts who'd be willing to chat, I'd love an intro. Appreciate your time!"

---

## Post-Call Debrief (Do This Immediately)

**Within 5 minutes of hanging up, answer these questions:**

1. **Wedge validation:** Which of the 3 sub-wedges resonated most?
   - [ ] Tool fragmentation
   - [ ] Corporate credibility loss
   - [ ] Airbnb refugee
   
2. **Pain intensity:** On a scale of 1-10, how acute is their pain?
   - 1-3 = Not a real problem
   - 4-6 = Annoying but livable
   - 7-8 = Actively looking for a solution
   - 9-10 = Desperate, would pay today

3. **Best verbatim quote:** What's the single most powerful thing they said?

4. **Quantified pain:** Did they give you hard numbers (time, money, lost deals)?
   - Time cost: ___ hours/month
   - Money cost: $___ /month in lost deals or wasted spend
   - WTP: $___ /month per property

5. **Red flags:** Anything that suggests this isn't a real problem?
   - [ ] No quantified pain
   - [ ] WTP < $10/month
   - [ ] Said "everything is fine"
   - [ ] Couldn't articulate impact

6. **Green flags:** Anything that suggests this is a hair-on-fire problem?
   - [ ] Quantified time/money cost
   - [ ] Told multiple stories of pain
   - [ ] WTP ≥ $50/month
   - [ ] Asked when you'll build it

7. **Follow-up action:** Should you re-engage this person?
   - [ ] Yes — high-intent prospect, keep warm
   - [ ] Maybe — lukewarm, add to nurture list
   - [ ] No — not a real buyer

---

## Interview Notes Template

Use this template during the call (copy into a doc/notepad):

```
HOST INTERVIEW NOTES
Date: ___________
Name: ___________
Market: ___________
Property Count: ___________
Booking Platforms: ___________

SITUATION (3 min):
Tech stack: 
  1. ___________
  2. ___________
  3. ___________
  Total count: ___
Workflow steps (last booking):
  1. ___________
  2. ___________
  3. ___________
  Manual steps: ___

PROBLEM (5 min):

[Sub-Wedge A: Tool Fragmentation]
- Most annoying part: ___________
- Time per booking: ___ min/hours
- Error stories: ___________
- QUOTE: "___________"

[Sub-Wedge B: Corporate Credibility]
- Corporate inquiries? YES / NO
- Last lost deal story: ___________
- Feature gaps: ___________
- QUOTE: "___________"

[Sub-Wedge C: Airbnb Refugee]
- Shifted away from Airbnb? YES / NO
- Reason: ___________
- Transition pain: ___________
- QUOTE: "___________"

IMPLICATION (3 min):
- Time cost: ___ hours/month × $___ /hour = $___ /month
- Money cost (lost deals): ___ deals/month × $___ /deal = $___ /month
- Opportunity cost: ___________
- Stress/emotion: "___________"

NEED-PAYOFF (3 min):
- Ideal solution: ___________
- Impact if solved: ___________
- WTP: $___ /month per property
- Urgency: High / Medium / Low
- Current alternatives: ___________
- Beta interest: Yes / Maybe / No

POST-CALL DEBRIEF:
- Wedge validation: [ ] A [ ] B [ ] C
- Pain intensity (1-10): ___
- Best quote: "___________"
- Quantified pain: Time: ___ hrs/mo | Money: $___ /mo | WTP: $___ /mo
- Red flags: ___________
- Green flags: ___________
- Follow-up action: [ ] Yes [ ] Maybe [ ] No
```

---

## Call Script Adaptation Guidelines

### If the call is going long (13+ minutes):

> "Hey, I want to be respectful of your time — we're at 13 minutes. I have 2 more quick questions, or I can let you go. What do you prefer?"

### If they start asking YOU questions about the solution:

> "Great question — let me finish understanding your situation first, and then I'm happy to share what I'm thinking. Cool?"

**Key principle:** Don't pitch until you've completed Need-Payoff. If you pitch early, you lose control of the conversation.

### If they say "I don't really have that problem":

> "Interesting! So what *is* your biggest operational headache right now?"

**Adapt:** Pivot to open-ended exploration. You might discover a new wedge.

### If they're giving one-word answers:

> "Help me understand — can you walk me through a specific example?"

**Key principle:** Stories > abstractions. Keep probing for specifics.

---

## Success Metrics for Call Quality

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| **Verbatim quotes captured** | ≥3 | You're listening, not just talking |
| **Quantified pain (time or money)** | 100% | Pain is real and measurable |
| **WTP disclosed** | 100% | They're a qualified buyer |
| **Urgency articulated** | ≥70% | Problem is acute enough to act on |
| **Beta interest** | ≥50% | They'd actually use the solution |

If below targets:
- **Low quotes** → You're talking too much. Let them talk.
- **No quantified pain** → You're not asking Implication questions hard enough.
- **No WTP** → You're not building enough urgency in Implication.
- **Low beta interest** → Pain isn't acute, or they don't trust you yet.

---

## Next Steps After 10 Calls

After 10 calls, synthesize:

1. **Wedge validation:** Which sub-wedge came up most frequently?
2. **Avg WTP:** What's the median WTP? (This sets your pricing anchor.)
3. **Common quotes:** What language do they use? (This becomes your copy.)
4. **Quantified pain distribution:** How many gave hard time/money numbers?
5. **Urgency distribution:** How many said "I need this now"?

**Decision criteria:**
- If ≥7/10 calls validate the same wedge + WTP ≥$30 → You have a real problem worth solving
- If <5/10 calls validate + WTP <$20 → Pivot or re-scope
- If no quantified pain across all calls → Not a real problem
