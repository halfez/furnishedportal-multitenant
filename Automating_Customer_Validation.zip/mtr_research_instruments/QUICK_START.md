# Quick Start Guide: MTR Host Customer Validation

## Get Started in 15 Minutes

### Step 1: Choose Your First 10 Targets (5 minutes)

Pick **10 MTR hosts** to reach out to. Use this mix:
- **3-4 Tier 1 targets** (your ideal customers — spend 10 min researching each)
- **3-4 Tier 2 targets** (good fit — spend 3 min researching each)
- **2-3 Tier 3 targets** (volume plays — spend 1 min each)

**Where to find them:**
- Facebook groups: "Furnished Finder Hosts," "MTR Host Community"
- Instagram: Search #MTRhost #FurnishedRental
- LinkedIn: Search "MTR host" or "medium term rental"

**Add them to:** `outreach_tracker_template.csv`

---

### Step 2: Personalize Your First Outreach (5 minutes)

Pick **Template A, B, C, or D** from `outreach_dm_template.md` based on what you know:
- **Template A** (Tool Fragmentation) — Default choice if you don't know their pain point
- **Template B** (Corporate Credibility) — If they mention corporate clients anywhere
- **Template C** (Airbnb Refugee) — If they used to be on Airbnb
- **Template D** (General) — High-volume, low-personalization

**Customize:**
- Replace `{first_name}`, `{market}`, `{property_name}` with real data
- Add one specific detail if Tier 1 (e.g., "I saw you use Hospitable...")

---

### Step 3: Send Outreach (3 minutes)

Send your **10 outreach messages** via:
- Instagram DM (highest response rate)
- Facebook Group DM (if they're active in groups)
- LinkedIn (for corporate-focused hosts)
- Email (if you have it)

**Always offer 4 participation formats:**
> "Happy to do a quick call, Zoom, text Q&A, or I can send you a 3-min survey — whatever works for your schedule."

---

### Step 4: Respond to Replies (2 minutes each)

When they reply, immediately send the appropriate instrument:

| They said... | Send them... |
|-------------|-------------|
| "Send me the survey" | Google Forms link (you'll create this in Step 5) |
| "Let's do a call" | Calendar link or suggest 2-3 times |
| "Text works" | Start `text_qa_flow.md` Template A, B, or C |
| "What's this for?" | "I'm researching MTR operational pain points. I run 2 properties in San Antonio and kept hitting issues, so I'm seeing if it's just me or a pattern. Your insights would be super helpful!" |

---

### Step 5: Set Up Your Survey (10 minutes) — Optional

If you want to use the survey format:

**Option A: Google Forms (Recommended)**
1. Go to [Google Forms](https://forms.google.com)
2. Create new form
3. Copy questions from `survey_template.md` (Q1-Q10)
4. Set Q1, Q2, Q3, Q4, Q7, Q9 as **Required**
5. Enable "Show progress bar"
6. Get shareable link
7. Test it yourself (should take <3 min)

**Option B: Self-Hosted HTML**
1. Upload `survey_template.html` to your web host
2. Replace `https://formspree.io/f/YOUR_FORM_ID` with your Formspree ID (or other form backend)
3. Test submission
4. Share URL

---

### Step 6: Conduct Your First Call (15 minutes)

When someone agrees to a call:
1. **Prepare:** Research them (5 min) — see "Pre-Call Checklist" in `call_script.md`
2. **Open the script:** Have `call_script.md` open during the call
3. **Follow SPIN framework:**
   - Intro (1 min)
   - Situation (3 min)
   - Problem (5 min) — **Test all 3 sub-wedges**
   - Implication (3 min)
   - Need-Payoff (3 min)
4. **Take notes:** Use the "Interview Notes Template" at the bottom of `call_script.md`
5. **Capture quotes:** Write down their exact words when they describe pain
6. **Ask for WTP:** "What would you pay per month per property to solve this?"
7. **Debrief immediately:** Within 5 min of hanging up, fill out post-call debrief

---

### Step 7: Track Everything (Ongoing)

After each response, update `outreach_tracker_template.csv`:
- Mark "Response?" as Yes/No
- Log "Format Chosen" (Survey/Call/Text)
- Log "Pain Intensity" (1-10)
- Log "Primary Wedge" (A/B/C)
- Log "WTP" ($/month)
- Add any notes

---

### Step 8: Synthesize After 5 Responses (30 minutes)

After your first **5 completed responses** (survey, call, or text):

1. **Open a spreadsheet** and calculate:
   - How many mentioned Sub-Wedge A (Tool Fragmentation)? ___ /5
   - How many mentioned Sub-Wedge B (Corporate Credibility)? ___ /5
   - How many mentioned Sub-Wedge C (Airbnb Refugee)? ___ /5
   - Median WTP: $___
   - Avg Pain Intensity: ___ /10

2. **Extract 3-5 verbatim quotes** (copy them into `verbatim_quotes.md`)

3. **Decide:**
   - **Green light:** ≥3/5 articulate pain + Median WTP ≥$20 → Continue to 15-20 responses
   - **Yellow flag:** Mixed signals → Refine questions or target segment
   - **Red flag:** <2/5 articulate pain or WTP <$10 → Pivot hypothesis

---

## Daily Workflow (Once You're Running)

**Morning (15 min):**
- Send 5-10 new outreach messages
- Respond to any replies from yesterday

**Midday (30 min):**
- Conduct 1-2 calls (if scheduled)
- Complete 3-5 text Q&A conversations (async)

**Evening (15 min):**
- Update `outreach_tracker.csv`
- Review survey responses
- Plan tomorrow's outreach targets

**Weekly (1 hour):**
- Synthesize last week's data
- Update `wedge_validation_summary.md`
- Identify patterns and top quotes

---

## First Week Goals

By end of Week 1, you should have:
- [ ] Sent 20-30 outreach messages
- [ ] Received 5-10 responses (15-30% response rate)
- [ ] Completed 5 interviews (any format: survey/call/text)
- [ ] Identified which sub-wedge appears most frequently
- [ ] Collected 5-10 verbatim quotes
- [ ] Median WTP estimate (even if small sample)

**If you hit these goals:** You're on track. Continue to 15-20 responses for validation.

**If you're below:** Adjust your outreach strategy (better personalization, different channels, different templates).

---

## Red Flags to Watch For

Stop and pivot if you see:
- [ ] <10% response rate to outreach (your message isn't resonating)
- [ ] <40% completion rate for surveys/calls (questions are too hard or too many)
- [ ] Majority say "no real pain" or "everything is fine"
- [ ] Median WTP <$10 (pain isn't acute enough to monetize)
- [ ] No consistent wedge emerges (hypothesis is too broad or wrong segment)

---

## Green Flags to Celebrate

You're onto something if you see:
- [ ] >20% response rate to outreach (message resonates)
- [ ] >60% completion rate for surveys/calls (questions are good)
- [ ] ≥60% mention the same pain point (wedge is validated)
- [ ] Median WTP ≥$30 (pain is acute and monetizable)
- [ ] People ask "When can I sign up?" (urgency signal)

---

## Resources at a Glance

| File | Use It For |
|------|------------|
| **README.md** | Master guide — when to use each instrument, synthesis framework |
| **outreach_dm_template.md** | Writing your first DM to hosts |
| **survey_template.md** | Setting up Google Forms or understanding question design |
| **survey_template.html** | Self-hosted survey option |
| **call_script.md** | Conducting 15-minute SPIN interviews |
| **text_qa_flow.md** | Async text/SMS/WhatsApp conversations |
| **outreach_tracker_template.csv** | Tracking all responses and data |
| **QUICK_START.md** (this file) | Getting started in 15 minutes |

---

## Need Help?

**Stuck on something?**
- Review the "Common Pitfalls" section in `README.md`
- Reference the sales/marketing skills for deeper SPIN methodology context
- Adapt templates to your needs — these are starting points, not rigid scripts

**Good luck! 🚀**

---

**Last Updated:** 2026-04-29
