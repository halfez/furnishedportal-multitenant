# MTR Host Outreach DM Template

## Positioning
**Your Identity:** Peer researcher (MTR operator, not vendor/salesperson)  
**Your Ask:** Their expertise for research  
**Their Commitment:** 15 minutes, their choice of format

---

## Template A: Tool Fragmentation Angle

**Subject:** Quick question from a fellow {market} MTR host?

**Body:**
Hey {first_name} — I run 2 MTRs in San Antonio and I'm researching how hosts like you manage operations after a booking comes in. I keep hearing about people juggling 5-7 different tools and I'm trying to understand if this is universal or just me. Can I steal 15 minutes of your time? Happy to do a quick call, Zoom, text Q&A, or even just a 3-min survey — whatever works for your schedule.

**Personalization Variables:**
- `{first_name}` — Prospect's first name
- `{market}` — Their city/region (e.g., "Austin", "Denver")
- Tool stack reference (optional): "I noticed you use {tech_stack} — curious how that's working for you"

---

## Template B: Corporate Inquiry Angle

**Subject:** Corporate MTR research — need your insights

**Body:**
{first_name}, I operate {property_name} here in San Antonio and I'm doing research on how MTR hosts handle corporate inquiries. Specifically, I'm trying to figure out why some convert and others ghost. Would you be open to a quick 15-min conversation about your experience? I can do phone, Zoom, async text, or send you a 3-min survey — totally your call.

**Personalization Variables:**
- `{first_name}` — Prospect's first name
- `{property_name}` — Your property name/brand
- Market reference: "...especially in {market} where corporate demand is picking up"

---

## Template C: Airbnb Migration Angle

**Subject:** Fellow MTR host researching the STR→MTR shift

**Body:**
Hey {first_name} — I'm a MTR operator in San Antonio doing research for a project. I've talked to a bunch of hosts who've shifted away from Airbnb toward corporate MTR and I'm trying to document what drove that decision. Any chance you'd be willing to share your story? 15 minutes max — call, Zoom, text exchange, or 3-min survey, whatever's easiest.

**Personalization Variables:**
- `{first_name}` — Prospect's first name
- `{market}` — Their city (if known)
- Platform history (if known): "I saw you were on Airbnb back in {year}..."

---

## Template D: General Pain Point Discovery

**Subject:** MTR ops research — need 15 mins?

**Body:**
{first_name}, I run a couple MTRs in San Antonio and I'm researching the biggest operational headaches for hosts like us. Not selling anything — just documenting what sucks about running these properties so I can understand if my pain is universal. Would you spare 15 minutes? I'm flexible: phone, Zoom, text back-and-forth, or a super-short survey.

**Personalization Variables:**
- `{first_name}` — Prospect's first name
- `{market}` — Their city
- Property count (if known): "I saw you operate {property_count} units in {market}..."

---

## Format Options to Offer

Always give prospects **4 participation formats** (increases response rate ~40%):

1. **Phone call** — "I can call you at {time}"
2. **Zoom** — "Happy to jump on Zoom"
3. **Text Q&A** — "Or we can do this async over text"
4. **3-min survey** — "Or I can send you a quick survey (takes <3 min)"

---

## Response Handling

### If they reply "Send me the survey":
"Perfect — here's the link: [survey_link]. Takes under 3 minutes. Really appreciate it!"

### If they reply "Let's do a call":
"Awesome! Does [Day] at [Time] work? I'll call you at [their_number]. This is pure research — I'll ask you about your workflow and biggest pain points. No pitch, promise."

### If they reply "What's this for?":
"I'm documenting how MTR hosts manage operations — specifically where the biggest bottlenecks are. I operate 2 properties in San Antonio and I kept running into the same issues, so I wanted to see if it's just me or if this is a pattern across the industry. Your insights would be super helpful."

### If they ignore (follow-up after 3 days):
**Subject:** Re: Quick MTR research question

**Body:** "No worries if you're slammed — just wanted to bump this in case it got buried. If a call doesn't work, I can send you a 3-min survey instead. Either way, appreciate your time!"

---

## Personalization Depth Guidelines

### Tier 1 — Deep Personalization (Top 20 targets)
- Reference their specific property name or portfolio
- Mention their tech stack (if you found it on their website/social)
- Reference a recent post/review/news mention
- Estimated time investment: 5-10 minutes per DM

**Example:**
"Hey Sarah — I run 2 MTRs in San Antonio and I'm researching corporate booking workflows. I saw on your site that you use Hospitable + Wheelhouse — curious how you handle the handoff after a booking confirms. Can I steal 15 minutes?"

### Tier 2 — Segment Personalization (Next 50 targets)
- Reference their market
- Mention property count or booking platform
- Estimated time investment: 2-3 minutes per DM

**Example:**
"Hey Mike — I operate MTRs in San Antonio and I'm researching how Denver hosts handle corporate inquiries. Would you be open to a 15-min call to share your experience? Happy to work around your schedule."

### Tier 3 — Template Personalization (High-volume outreach)
- First name only
- Market (if known)
- Estimated time investment: 30 seconds per DM

**Example:**
"Hey Alex — I'm a MTR host doing research on operational pain points. Can I steal 15 minutes of your time? Happy to do call/Zoom/text/survey — your choice."

---

## Channel Selection

| Channel | Best For | Response Rate | Notes |
|---------|----------|---------------|-------|
| **Instagram DM** | Hosts active on IG | 15-25% | Warm, casual tone works best |
| **LinkedIn DM** | Corporate-focused hosts | 10-20% | More professional framing |
| **Facebook Group DM** | Community-active hosts | 20-35% | Reference the group in your intro |
| **Email** | Publicly listed contacts | 5-15% | Needs strongest subject line |
| **SMS/Text** | Warm intros/referrals | 40-60% | Only if you have their number |

---

## Subject Line A/B Test Variants

Test these variants to optimize open rates:

| Variant | Subject Line | Hypothesis |
|---------|--------------|------------|
| **A1** | Quick question from a fellow MTR host? | Peer curiosity |
| **A2** | {market} MTR host — 15 min research call? | Localized relevance |
| **A3** | Not selling anything — just need your expertise | Disarm sales fear |
| **A4** | MTR ops research (3-min survey or quick call) | Low-commitment framing |
| **A5** | Fellow host researching the Airbnb→MTR shift | Shared experience |

Track: Open Rate, Reply Rate, Conversion to Interview

---

## Key Principles

1. **No sales language** — Avoid "solution," "platform," "our product," etc.
2. **Lead with credibility** — "I run 2 MTRs in [city]" establishes peer status immediately
3. **Make it low-friction** — Offer 4 participation formats to maximize response
4. **Be specific** — "15 minutes" is better than "a quick chat" (reduces ambiguity)
5. **Honor their time** — If they choose survey, don't bait-and-switch to a call
6. **Follow up once** — Second touch after 3 days, then move on (no pestering)

---

## Success Metrics

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| **Open Rate** | >40% | Subject line effectiveness |
| **Reply Rate** | >15% | Message relevance + credibility |
| **Conversion to Interview** | >8% | Offer attractiveness + trust |
| **Survey Completion Rate** | >60% | Survey length + question quality |

If you're below targets:
- **Low open rate** → Test new subject lines
- **Low reply rate** → Increase personalization depth
- **Low conversion** → Simplify the ask or offer more formats
