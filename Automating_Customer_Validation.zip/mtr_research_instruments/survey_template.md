# MTR Host 3-Minute Survey Template

**Time to complete:** <3 minutes  
**Question count:** 10 questions (8 open-ended, 2 optional)  
**Purpose:** Test 3 sub-wedges + validate willingness to pay

---

## Google Forms Setup Instructions

### Form Settings
1. **Title:** "MTR Operations Research — Host Survey"
2. **Description:** "Thanks for helping with this research! This survey takes under 3 minutes. Your answers will help document the real operational challenges MTR hosts face. No sales pitch — just pure research."
3. **Settings:**
   - [ ] Limit to 1 response (OFF — allow anonymous)
   - [ ] Collect email addresses (OFF — make it optional at the end)
   - [ ] Show progress bar (ON)
   - [ ] Shuffle question order (OFF)

---

## Survey Questions

### Section 1: Context (1 question)

**Q1: How many MTR properties do you currently operate?**  
_Type: Short answer (text)_  
_Required: Yes_

**Why this question:** Segments responses by portfolio size; identifies if pain scales with property count.

---

### Section 2: Sub-Wedge A — Tool Fragmentation Post-Booking (3 questions)

**Q2: Walk me through what happens AFTER a booking is confirmed. What's your workflow?**  
_Type: Paragraph (long text)_  
_Required: Yes_  
_Helper text: "Think about the last booking you received. What steps did you take? What tools did you use? What took longer than it should have?"_

**Why this question:** Open-ended to capture verbatim workflow. Looking for mentions of multiple tools, manual steps, context-switching.

---

**Q3: How many different tools or platforms do you use to manage a single booking from confirmation to checkout?**  
_Type: Short answer (text)_  
_Required: Yes_  
_Helper text: "Examples: PMS, messaging app, smart lock software, cleaning scheduler, payment processor, etc."_

**Why this question:** Quantifies tool fragmentation. Benchmark: 3-5 tools = moderate pain, 6+ = severe pain.

---

**Q4: What's the most frustrating part of managing the post-booking workflow?**  
_Type: Paragraph (long text)_  
_Required: Yes_

**Why this question:** Captures the acute pain point in their own words. Prime for verbatim quotes.

---

### Section 3: Sub-Wedge B — Corporate Credibility Loss (2 questions)

**Q5: Tell me about the last time a corporate client or travel coordinator inquired about your property but didn't book. What happened?**  
_Type: Paragraph (long text)_  
_Required: No (optional)_  
_Helper text: "If you don't get corporate inquiries, feel free to skip this."_

**Why this question:** Tests if corporate/B2B credibility is a real issue. Looking for mentions of "looked unprofessional," "they wanted a portal," "asked for features I didn't have."

---

**Q6: Do corporate clients or travel coordinators ever ask you for features/capabilities you don't currently have? If so, what do they ask for?**  
_Type: Paragraph (long text)_  
_Required: No (optional)_  
_Helper text: "Examples: online booking portal, invoicing, consolidated billing, reporting, etc."_

**Why this question:** Validates the corporate credibility wedge. If responses mention "portal," "professional system," "invoicing," this is a signal.

---

### Section 4: Sub-Wedge C — Airbnb Refugee (2 questions)

**Q7: Have you shifted away from Airbnb (or other STR platforms) toward longer-term MTR bookings? If yes, what drove that decision?**  
_Type: Paragraph (long text)_  
_Required: Yes_

**Why this question:** Tests the Airbnb refugee hypothesis. Looking for mentions of "fees too high," "regulation crackdown," "wanted stability," "burnout from turnover."

---

**Q8: If you've made that shift, what's been the hardest part about transitioning from STR to MTR operations?**  
_Type: Paragraph (long text)_  
_Required: No (optional)_

**Why this question:** Uncovers transition pain. Could reveal new wedges (e.g., "finding corporate leads," "screening tenants," "lease terms").

---

### Section 5: Willingness to Pay (1 question)

**Q9: If there was a tool or service that eliminated your single biggest operational headache, what would you be willing to pay per month per property?**  
_Type: Multiple choice_  
_Required: Yes_

**Options:**
- Nothing — I'm not interested in solving this right now
- $10-25/month per property
- $26-50/month per property
- $51-100/month per property
- $101-200/month per property
- $200+/month per property

**Why this question:** Validates willingness to pay and establishes pricing anchor. If majority selects "Nothing," the pain isn't acute enough.

---

### Section 6: Follow-Up (1 question)

**Q10: Would you be open to a quick 15-minute follow-up call to dive deeper into any of your answers?**  
_Type: Short answer (text)_  
_Required: No (optional)_  
_Helper text: "If yes, please leave your email or phone number. If no, no worries!"_

**Why this question:** Converts survey respondents into interview pipeline. High-quality responses = prioritize for follow-up.

---

## Google Forms Creation Checklist

- [ ] Copy questions 1-10 into Google Forms
- [ ] Set Q1, Q2, Q3, Q4, Q7, Q9 as **Required**
- [ ] Set Q5, Q6, Q8, Q10 as **Optional**
- [ ] Add helper text where indicated
- [ ] Enable "Show progress bar"
- [ ] Test the form yourself — should complete in <3 minutes
- [ ] Generate shareable link (set to "Anyone with the link")
- [ ] Track responses in Google Sheets (auto-link)

---

## Response Analysis Framework

### Quantitative Signals

| Metric | What to Look For |
|--------|------------------|
| **Tool count (Q3)** | Average ≥5 tools = fragmentation is real |
| **WTP (Q9)** | If >50% select $26+, pain is acute enough to monetize |
| **Corporate conversion loss (Q5)** | If >30% have a story, corporate credibility wedge is valid |
| **Airbnb migration (Q7)** | If >40% have shifted, refugee wedge is valid |

### Qualitative Signals

Extract verbatim quotes from Q2, Q4, Q5, Q6, Q7, Q8 that include:
- **Emotion words:** "frustrating," "annoying," "waste of time," "wish I had"
- **Time quantifiers:** "takes me 2 hours," "spend 30 min per booking"
- **Money quantifiers:** "lost a $5K booking," "costs me $X/month"
- **Problem descriptions:** "juggling," "manually," "copy-pasting," "spreadsheet hell"

### Response Prioritization for Follow-Up Calls

**Tier 1 — Must interview:**
- High tool count (6+) + strong emotion in Q4 + WTP $51+
- Lost corporate deal (Q5) + mentioned specific feature gap
- Airbnb refugee with transition pain (Q7 + Q8)

**Tier 2 — Worth interviewing:**
- Moderate tool count (4-5) + WTP $26-50
- Corporate inquiry experience but no lost deal
- Any response with money/time quantifiers

**Tier 3 — Skip unless desperate:**
- Low tool count (<3) + WTP <$25
- "Everything is fine" responses
- No specific pain articulated

---

## Standalone HTML Version

See `survey_template.html` (included below) for a self-hosted version.

**Advantages of HTML version:**
- Full design control (can match your branding)
- No Google branding (looks more professional)
- Can embed on your own domain
- Export responses to your own database

**Disadvantages:**
- Need to host it yourself
- Need to configure form submission (e.g., Formspree, Basin, or custom backend)
- No built-in analytics (need to set up your own)

---

## Email Reminder for Non-Respondents

**Subject:** Quick reminder — MTR survey (takes <3 min)

**Body:**
Hey {first_name},

Just bumping this in case it got lost in your inbox. Would still love to get your input on the MTR operations survey — it takes under 3 minutes and your answers would be super helpful.

Here's the link: [survey_link]

If surveys aren't your thing, I'm also happy to do a quick 15-min call instead. Just let me know!

Thanks,  
[Your Name]

---

## Survey Distribution Strategy

1. **Send to Tier 1 prospects first** (highest quality, most engaged)
2. **Wait 48 hours** — analyze initial responses for signal strength
3. **If strong signal (>60% completion rate, high pain articulation):** Roll out to Tier 2 and 3
4. **If weak signal (<40% completion, low pain articulation):** Revise questions or pivot to calls instead

---

## Success Metrics

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| **Completion Rate** | >60% | Survey length and question quality |
| **Average Time to Complete** | <3 min | Survey isn't too long |
| **WTP ≥$26** | >50% | Pain is monetizable |
| **Follow-up opt-in (Q10)** | >25% | Respondents are engaged enough for deeper conversation |
| **Verbatim quote yield** | ≥3 quotes per response | Open-ended questions are working |

If below targets:
- **Low completion rate** → Survey is too long or questions are confusing
- **High completion but low WTP** → Pain isn't acute or solution framing is off
- **Low follow-up opt-in** → Respondents don't trust you yet or don't see value in deeper conversation
