# MTR Host Customer Validation Research Instruments

## Overview

This toolkit contains **4 research instruments** designed to validate customer pain points for MTR (Medium-Term Rental) hosts. Each instrument tests **3 sub-wedges** and follows proven customer validation frameworks (SPIN methodology, Mom Test principles, and qualitative research best practices).

---

## Research Objectives

### Primary Goal
Validate whether MTR hosts experience acute pain in one or more of these areas:

1. **Sub-Wedge A: Tool Fragmentation Post-Booking**
   - Hypothesis: Hosts juggle 5-7+ tools to manage a single booking from confirmation to checkout
   - Pain signal: Manual data entry, context switching, things falling through cracks
   
2. **Sub-Wedge B: Corporate Credibility Loss**
   - Hypothesis: Hosts lose corporate bookings because they lack professional booking infrastructure
   - Pain signal: Lost deals, feature requests (portal, invoicing), "looked like Airbnb" feedback
   
3. **Sub-Wedge C: Airbnb Refugee**
   - Hypothesis: Hosts shifting from STR to MTR struggle with tools built for short-term rentals
   - Pain signal: Airbnb fee pain, regulation fear, operational mismatch

### Secondary Goal
Quantify willingness to pay (WTP) and validate pricing assumptions ($25-100/month per property range).

---

## The 4 Research Instruments

| Instrument | Format | Time | Best For | Response Rate | Depth |
|------------|--------|------|----------|---------------|-------|
| **1. Outreach DM Template** | Text/DM | 2 min | Initial contact | — | — |
| **2. 3-Minute Survey** | Google Forms/HTML | <3 min | High-volume screening | 15-25% | Low |
| **3. Call Script (SPIN)** | Phone/Zoom | 15 min | Deep validation | 10-20% | High |
| **4. Text Message Q&A** | SMS/WhatsApp | 5-10 min async | Mobile-first hosts | 30-50% | Medium |

---

## When to Use Each Instrument

### Decision Tree

```
START: Who is this prospect and what's my goal?

├── First contact (cold outreach)?
│   └── Use: OUTREACH DM TEMPLATE
│       - Pick template variant based on wedge you want to test
│       - Offer 4 participation formats (call, Zoom, text, survey)
│       - Goal: Get a "yes" to any format
│
├── They said "Send me a survey"?
│   └── Use: 3-MINUTE SURVEY
│       - Google Forms for easy setup
│       - HTML version for custom branding
│       - Goal: Quick screening + identify high-intent prospects for follow-up calls
│
├── They said "Let's do a call"?
│   └── Use: CALL SCRIPT (SPIN)
│       - Book 15-minute slot
│       - Follow SPIN framework religiously
│       - Goal: Deep validation + quantified pain + verbatim quotes
│
├── They prefer async communication?
│   └── Use: TEXT MESSAGE Q&A
│       - WhatsApp, SMS, or Instagram DM
│       - 5-7 messages over hours/days
│       - Goal: Medium-depth validation without scheduling friction
│
└── They're a high-value target but non-responsive?
    └── Use: OUTREACH DM TEMPLATE (follow-up variant)
        - One follow-up after 3 days
        - Offer survey as lowest-friction option
        - If no response, move on
```

---

## Instrument Selection Guide

### Use **Survey** when:
- [ ] You need high-volume data (20+ responses)
- [ ] Prospects are busy and can't commit to a call
- [ ] You want to screen for high-intent prospects to interview later
- [ ] You need quantitative benchmarks (tool count, WTP distribution)

**Advantages:** Scalable, low time commitment, easy to distribute  
**Disadvantages:** No follow-up probing, lower response quality, no relationship building

---

### Use **Call Script** when:
- [ ] You need deep, nuanced insights
- [ ] You want verbatim quotes for marketing/positioning
- [ ] Prospect is high-value or high-intent
- [ ] You need to test multiple wedges in one conversation

**Advantages:** Deepest insights, builds relationship, can pivot based on answers  
**Disadvantages:** Time-intensive, lower response rate, requires scheduling

---

### Use **Text Q&A** when:
- [ ] Prospect is mobile-first (Instagram, WhatsApp active)
- [ ] You want conversational depth without scheduling friction
- [ ] You're targeting a younger demographic or busy operators
- [ ] Survey feels too formal, call feels too intrusive

**Advantages:** High response rate, conversational, async-friendly  
**Disadvantages:** Limited depth (can't probe beyond 1-2 follow-ups), manual effort

---

## Personalization Strategy

### Tier 1: Deep Personalization (Top 20 strategic targets)
**Time investment:** 10-15 minutes per outreach

**Research checklist:**
- [ ] Scrape their website/social for property portfolio details
- [ ] Identify their tech stack (Hospitable, Guesty, Wheelhouse, etc.)
- [ ] Find recent content (posts, reviews, news mentions)
- [ ] Check if they're active in MTR communities (Facebook groups, LinkedIn)

**Outreach approach:**
- Reference their specific property by name
- Mention their tech stack and ask about it
- Reference a recent post or achievement
- Use Template A or B (most relevant wedge)

**Example:**
> "Hey Sarah — I run 2 MTRs in San Antonio and I noticed on your site you're using Hospitable + Wheelhouse. I'm researching how hosts manage the handoff after a booking confirms and I keep hearing about tool juggling. Can I steal 15 minutes to hear about your workflow?"

---

### Tier 2: Segment Personalization (Next 50 targets)
**Time investment:** 3-5 minutes per outreach

**Research checklist:**
- [ ] Identify their market/city
- [ ] Estimate property count (if visible)
- [ ] Note primary booking platform (Airbnb, Furnished Finder, direct)

**Outreach approach:**
- Reference their market
- Mention property count or platform
- Use Template A, B, or C (test which performs best)

**Example:**
> "Hey Mike — I operate MTRs in San Antonio and I'm researching how Denver hosts handle corporate inquiries. You run 3-4 units, right? Would you be open to a quick 15-min call to share your experience?"

---

### Tier 3: Template Personalization (High-volume outreach)
**Time investment:** 1 minute per outreach

**Research checklist:**
- [ ] First name
- [ ] City/market (if known)

**Outreach approach:**
- First name + market
- Generic pain discovery framing
- Use Template D (general)

**Example:**
> "Hey Alex — I'm a MTR host researching operational pain points. Can I steal 15 minutes? Happy to do call/Zoom/text/survey — your choice."

---

## Response Organization System

### Folder Structure

```
mtr_research/
├── outreach_tracker.csv
├── responses/
│   ├── surveys/
│   │   └── survey_responses.csv (exported from Google Forms)
│   ├── calls/
│   │   ├── call_001_transcript.txt
│   │   ├── call_002_transcript.txt
│   │   └── ...
│   └── texts/
│       ├── text_001_conversation.txt
│       ├── text_002_conversation.txt
│       └── ...
└── synthesis/
    ├── verbatim_quotes.md
    ├── wedge_validation_summary.md
    └── wtp_analysis.csv
```

---

### Outreach Tracker (CSV Template)

| Column | Description | Example |
|--------|-------------|---------|
| **Name** | First Last | Sarah Johnson |
| **Market** | City/State | Austin, TX |
| **Property Count** | Number of units | 4 |
| **Contact** | Phone/Email/Instagram | @sarahmtr |
| **Tier** | Personalization level | Tier 1 |
| **Template Used** | A/B/C/D | Template B (Corporate) |
| **Outreach Date** | YYYY-MM-DD | 2026-04-29 |
| **Response?** | Yes/No | Yes |
| **Response Date** | YYYY-MM-DD | 2026-04-30 |
| **Format Chosen** | Survey/Call/Text | Call |
| **Completed?** | Yes/No | Yes |
| **Completion Date** | YYYY-MM-DD | 2026-05-02 |
| **Pain Intensity** | 1-10 | 8 |
| **Primary Wedge** | A/B/C | B (Corporate) |
| **WTP** | $/month per property | $75 |
| **Beta Interest** | Yes/Maybe/No | Yes |
| **Follow-Up Action** | Next step | Add to beta list |
| **Notes** | Key insights | Lost $10K deal, needs invoicing |

**Download:** `outreach_tracker_template.csv` (included in this repo)

---

### Response Capture Best Practices

#### For Surveys:
1. Export Google Forms responses to CSV after every 5 responses
2. Tag each response with completion date and response ID
3. Highlight high-intent responses (WTP ≥$50, strong pain articulation)
4. Flag for follow-up calls

#### For Calls:
1. Record (with permission) or take detailed notes during the call
2. Use the "Interview Notes Template" from `call_script.md`
3. Immediately after the call (within 5 minutes):
   - Fill out post-call debrief
   - Capture 2-3 best verbatim quotes
   - Calculate quantified pain (time × $ or lost deals × $)
4. Save transcript/notes as `call_XXX_[name]_[date].txt`

#### For Text Conversations:
1. Screenshot or copy-paste the full conversation
2. Use the "Text Capture Template" from `text_qa_flow.md`
3. Tag with: Wedge validation (A/B/C), WTP, pain intensity (1-10)
4. Save as `text_XXX_[name]_[date].txt`

---

## Synthesis Framework: Path to "Definition of Done"

### Definition of Done (Customer Validation Phase)

You've **completed customer validation** when you can confidently answer these questions:

1. ✅ **Is the pain real?**
   - ≥70% of respondents articulate a specific, quantified pain
   - Pain is tied to time cost (hours/week) or money cost (lost deals, wasted spend)

2. ✅ **Which wedge is strongest?**
   - One sub-wedge (A, B, or C) emerges in ≥60% of conversations
   - Respondents use consistent language to describe the pain

3. ✅ **Is the pain acute?**
   - ≥50% rate pain intensity ≥7/10
   - ≥40% express urgency ("I need this now," "wish I had this yesterday")

4. ✅ **Will they pay?**
   - Median WTP ≥$30/month per property
   - ≥50% of respondents willing to pay $26+

5. ✅ **What should we build?**
   - Feature requests cluster around 3-5 common themes
   - You can articulate a clear MVP that solves the #1 pain

---

### Synthesis Workflow

#### After 5 Responses (Initial Signal Detection)

**Goal:** Identify early patterns and decide whether to continue.

**Checklist:**
- [ ] Aggregate survey/call/text data into `outreach_tracker.csv`
- [ ] Calculate:
  - Avg tool count (Sub-Wedge A)
  - % with corporate conversion issues (Sub-Wedge B)
  - % who shifted from Airbnb (Sub-Wedge C)
  - Median WTP
- [ ] Extract 3-5 verbatim quotes that represent each wedge
- [ ] Decision: Is there enough signal to continue? Or pivot?

**Early Stop Criteria (RED FLAGS):**
- All respondents say "no real pain" or "everything is fine"
- Median WTP <$10
- No quantified pain (time or money) in any response
- **Action:** Pivot wedge hypothesis or change target segment

**Green Light Criteria (CONTINUE):**
- ≥3/5 articulate a specific pain
- Median WTP ≥$20
- At least one wedge appears in ≥60% of responses
- **Action:** Continue to 15-20 responses

---

#### After 15-20 Responses (Wedge Validation)

**Goal:** Validate which wedge is strongest and quantify WTP.

**Checklist:**
- [ ] Update `outreach_tracker.csv` with all responses
- [ ] Create `wedge_validation_summary.md` (template below)
- [ ] Create `wtp_analysis.csv` (template below)
- [ ] Extract 10-15 best verbatim quotes into `verbatim_quotes.md`
- [ ] Calculate:
  - **Wedge A frequency:** X/15 mentioned tool fragmentation
  - **Wedge B frequency:** X/15 mentioned corporate credibility
  - **Wedge C frequency:** X/15 mentioned Airbnb migration
  - **Median WTP:** $X/month per property
  - **Avg pain intensity:** X/10

**Decision Criteria:**

| Outcome | Criteria | Action |
|---------|----------|--------|
| **Strong Validation** | One wedge ≥60% + Median WTP ≥$30 + Avg pain ≥7 | Proceed to MVP scoping |
| **Moderate Validation** | One wedge ≥50% + Median WTP ≥$20 + Avg pain ≥5 | Continue to 30 responses or narrow target segment |
| **Weak Validation** | No wedge >40% or Median WTP <$20 or Avg pain <5 | Pivot hypothesis or target different segment |

---

#### After 30+ Responses (Final Synthesis)

**Goal:** Lock in positioning, pricing, and MVP scope.

**Checklist:**
- [ ] Final update to `outreach_tracker.csv`
- [ ] Write final `wedge_validation_summary.md` with:
  - Winning wedge + frequency
  - Quantified pain (median time cost, median money cost)
  - WTP distribution (histogram)
  - Top 20 verbatim quotes
  - Feature request ranking
- [ ] Create `mvp_spec.md` based on findings:
  - Core pain to solve (from winning wedge)
  - Must-have features (from feature requests)
  - Pricing anchor (from WTP analysis)
  - Target personas (from respondent segments)

**Final Validation Checklist:**
- [ ] ≥70% of respondents articulate quantified pain
- [ ] One wedge dominates (≥60% frequency)
- [ ] Median WTP ≥$30/month per property
- [ ] ≥40% express high urgency (need it now)
- [ ] ≥30% opt in for beta/early access

**If all boxes checked:** ✅ Customer validation complete. Proceed to MVP build.

---

## Templates for Synthesis Documents

### Template: `wedge_validation_summary.md`

```markdown
# MTR Host Wedge Validation Summary

**Date:** [YYYY-MM-DD]  
**Sample Size:** X responses (Y calls, Z surveys, W texts)

---

## Winning Wedge

**Sub-Wedge [A/B/C]: [Name]**
- **Frequency:** X/Y respondents (Z%)
- **Pain Intensity (Avg):** X.X/10
- **Quantified Pain:**
  - Time cost: X hours/month (median)
  - Money cost: $X/month in lost deals or wasted spend (median)
- **WTP (Median):** $X/month per property

---

## Secondary Wedge(s)

**Sub-Wedge [A/B/C]: [Name]**
- **Frequency:** X/Y respondents (Z%)
- **Pain Intensity (Avg):** X.X/10
- **Key Insight:** [1-2 sentence summary]

---

## Verbatim Quotes (Top 10)

1. **[Name, Market]:** "Quote about pain..." — [Wedge A/B/C]
2. **[Name, Market]:** "Quote about pain..." — [Wedge A/B/C]
3. [...]

---

## Feature Requests (Ranked by Frequency)

| Feature | Frequency | Wedge | Example Quote |
|---------|-----------|-------|---------------|
| [Feature 1] | X/Y (Z%) | A/B/C | "Quote..." |
| [Feature 2] | X/Y (Z%) | A/B/C | "Quote..." |
| [...] | | | |

---

## WTP Distribution

| Range | Count | % |
|-------|-------|---|
| $0-10 | X | Z% |
| $11-25 | X | Z% |
| $26-50 | X | Z% |
| $51-100 | X | Z% |
| $100+ | X | Z% |

**Median:** $X/month per property  
**Mean:** $X/month per property

---

## Segment Insights

| Segment | Sample Size | Primary Wedge | Median WTP | Key Insight |
|---------|-------------|---------------|------------|-------------|
| 1-2 properties | X | A/B/C | $X | [Insight] |
| 3-5 properties | X | A/B/C | $X | [Insight] |
| 6+ properties | X | A/B/C | $X | [Insight] |

---

## Recommendation

[Based on the data, recommend next steps: proceed to MVP, pivot wedge, expand sample size, etc.]
```

---

### Template: `wtp_analysis.csv`

| Respondent ID | Name | Market | Property Count | WTP ($/mo/property) | Pain Intensity (1-10) | Primary Wedge | Beta Interest |
|---------------|------|--------|----------------|---------------------|----------------------|---------------|---------------|
| 001 | Sarah J. | Austin, TX | 4 | 75 | 8 | B | Yes |
| 002 | Mike R. | Denver, CO | 2 | 30 | 6 | A | Maybe |
| [...] | | | | | | | |

**Summary Stats:**
- **Median WTP:** $X
- **Mean WTP:** $X
- **Std Dev:** $X
- **Range:** $X - $X

---

### Template: `verbatim_quotes.md`

```markdown
# MTR Host Verbatim Quotes

**Purpose:** These quotes are gold for marketing copy, positioning, and product messaging. Use them verbatim in landing pages, ads, and pitch decks.

---

## Sub-Wedge A: Tool Fragmentation

> "I'm juggling like 7 different apps just to get someone checked in. It's insane. I spend 30 minutes per booking just copying info from one system to another."
— **Sarah, Austin, TX** (4 properties)

> "The worst part is when something falls through the cracks. I forgot to send a door code once because I updated it in one system but not the other. Guest was locked out for 2 hours."
— **Mike, Denver, CO** (2 properties)

[Add 5-10 more quotes for Wedge A]

---

## Sub-Wedge B: Corporate Credibility Loss

> "I had a corporate relocation company ask for an online booking portal and invoicing. I sent them my Airbnb link and never heard back. I probably looked like an amateur."
— **Jennifer, Phoenix, AZ** (3 properties)

> "These corporate clients want net-30 payment terms and consolidated billing. I can't do that with my current setup, so I lose the deals."
— **Carlos, San Diego, CA** (5 properties)

[Add 5-10 more quotes for Wedge B]

---

## Sub-Wedge C: Airbnb Refugee

> "Airbnb fees were eating 15% of my revenue. I switched to MTR but all my tools are still built for short-term stays. It's a pain."
— **Emma, Seattle, WA** (6 properties)

> "Local regulations killed my STR business. I pivoted to MTR but the transition was brutal — finding corporate tenants, pricing differently, my PMS wasn't built for it."
— **David, Portland, OR** (4 properties)

[Add 5-10 more quotes for Wedge C]

---

## Urgency & WTP Quotes

> "If you build this, I'd pay $100/month per property easily. This is costing me way more than that in lost time and deals."
— **Sarah, Austin, TX**

> "I need this yesterday. Seriously. When can I sign up?"
— **Jennifer, Phoenix, AZ**

[Add 5-10 more urgency quotes]
```

---

## Channel Strategy for Outreach

### Where to Find MTR Hosts

| Channel | Pros | Cons | Best Outreach Format |
|---------|------|------|----------------------|
| **Facebook Groups** (e.g., "Furnished Finder Hosts") | High engagement, community trust | Competitive noise | Template A or D + Survey |
| **Instagram** (hashtag #MTRhost #FurnishedRental) | Visual, mobile-first, high response rate | Limited search/filter | Template A + Text Q&A |
| **LinkedIn** (search "MTR host" or "furnished rental") | Professional, corporate-focused hosts | Lower response rate | Template B + Call |
| **Furnished Finder** (scrape host profiles) | Targeted, high-quality leads | Time-intensive to scrape | Template C + Survey or Call |
| **Airbnb** (find hosts with 30+ day listings) | Large volume | May not self-identify as MTR | Template C (Airbnb refugee) |
| **Direct outreach** (referrals from interviewed hosts) | Highest trust, warm intro | Limited scale | All formats work |

---

### Outreach Cadence

**Initial Outreach:**
- Day 1: Send outreach DM (Template A/B/C/D)
- Day 3: Follow-up if no response (offer survey as low-friction option)
- Day 7: Final touch if still no response, then move on

**Post-Response:**
- Within 24 hours: Send chosen format (survey link, call time, text Q&A start)
- For calls: Send calendar invite + reminder 24h before
- For surveys: Send reminder after 48h if not completed
- For texts: Allow 24-48h between messages (async-friendly)

**Post-Completion:**
- Within 24h: Send thank-you message
- Add to nurture list (if they opted in for beta)
- Request referrals: "Know any other MTR hosts who'd be open to chatting?"

---

## Quality Control Checklist

Before marking validation "complete," audit your research process:

### Data Quality
- [ ] ≥70% of responses include quantified pain (time or money)
- [ ] ≥50% of responses include verbatim quotes you can use
- [ ] ≥80% of WTP questions were answered (not skipped)
- [ ] No obvious response bias (e.g., all from one city or one property size)

### Sample Diversity
- [ ] Respondents from ≥3 different markets/cities
- [ ] Mix of property counts (1-2, 3-5, 6+ properties)
- [ ] Mix of booking platforms (Airbnb, Furnished Finder, direct, corporate)
- [ ] Mix of formats (surveys, calls, texts)

### Wedge Validation Rigor
- [ ] Tested all 3 sub-wedges in every conversation
- [ ] Avoided leading questions or confirmation bias
- [ ] Captured both positive AND negative signals (not just what you wanted to hear)
- [ ] Validated pain is acute (not just "nice to have")

### Pricing Validation
- [ ] WTP question was asked directly (not implied)
- [ ] Respondents gave specific numbers (not "depends" or "not sure")
- [ ] WTP is anchored to value ("If this solved X, would you pay Y?")

---

## Common Pitfalls (And How to Avoid Them)

### Pitfall 1: Confirmation Bias
**What it looks like:** You only hear what you want to hear. You ignore signals that contradict your hypothesis.

**How to avoid:**
- Actively listen for "I don't have that problem" or "That's not a big deal for me"
- Track both positive AND negative signals in your notes
- If someone says "everything is fine," probe deeper: "What *is* your biggest headache?"

---

### Pitfall 2: Leading Questions
**What it looks like:** "You must hate juggling 7 different tools, right?"

**How to avoid:**
- Ask open-ended questions: "Walk me through your workflow after a booking confirms."
- Don't put words in their mouth
- Follow the SPIN framework from the call script

---

### Pitfall 3: Happy Ears
**What it looks like:** They say "That sounds interesting" and you interpret it as "I'd buy this tomorrow."

**How to avoid:**
- Validate interest with WTP: "What would you pay for that?"
- Check urgency: "How soon would you need this?"
- Ask for commitment: "Would you beta test this?"

---

### Pitfall 4: Solution Pitching Too Early
**What it looks like:** You describe your solution before they've articulated the pain.

**How to avoid:**
- Complete Problem and Implication stages of SPIN before mentioning solutions
- Let *them* describe what the ideal solution would look like (Need-Payoff)
- If they ask "What are you building?", defer: "Let me understand your situation first, then I'll share."

---

### Pitfall 5: Small Sample Size
**What it looks like:** You talk to 5 people, they all say "yes," and you assume it's validated.

**How to avoid:**
- Minimum 15-20 responses for initial validation
- 30+ for high-confidence validation
- Ensure sample diversity (markets, property sizes, platforms)

---

## Next Steps After Validation

Once you've completed customer validation (all boxes checked in "Definition of Done"), proceed to:

1. **MVP Scoping**
   - Define core features based on winning wedge
   - Prioritize "must-haves" vs. "nice-to-haves"
   - Set pricing based on WTP analysis

2. **Positioning & Messaging**
   - Use verbatim quotes for landing page copy
   - Frame value prop around quantified pain ("Save X hours/month, close Y more deals")
   - Target the winning wedge first, expand later

3. **Beta Recruitment**
   - Reach out to respondents who opted in for beta
   - Offer early access at discounted rate (50% off for first 6 months)
   - Set up feedback loops (weekly check-ins, feature requests)

4. **Build & Iterate**
   - Ship MVP to beta users
   - Validate that the solution actually solves the pain (measure time saved, deals won, etc.)
   - Iterate based on feedback

---

## Contact & Support

**Questions about these research instruments?**

- Review the individual instrument files for detailed guidance
- Reference the sales/marketing skills for deeper methodology context
- Adapt templates to your specific needs — these are starting points, not rigid scripts

**Good luck with your customer validation! 🚀**

---

## Appendix: Quick Reference

### SPIN Framework (Call Script)
1. **Situation:** Current state, context (use sparingly)
2. **Problem:** Uncover pain, difficulties, dissatisfactions
3. **Implication:** Expand the cost and urgency of the problem
4. **Need-Payoff:** Get them to articulate the value of a solution

### Mom Test Principles
- Talk about their life, not your idea
- Ask about specifics in the past, not generics or opinions about the future
- Talk less, listen more

### Key Metrics to Track
- **Response Rate:** % who reply to outreach
- **Completion Rate:** % who finish survey/call/text flow
- **Pain Intensity:** Avg rating (1-10 scale)
- **WTP:** Median $/month per property
- **Beta Interest:** % who opt in for early access
- **Wedge Frequency:** % who mention each sub-wedge

---

## Files in This Toolkit

1. **README.md** (this file) — Master guide
2. **outreach_dm_template.md** — DM templates for initial contact
3. **survey_template.md** — Google Forms setup + question bank
4. **survey_template.html** — Standalone HTML survey (self-hosted option)
5. **call_script.md** — 15-minute SPIN interview script
6. **text_qa_flow.md** — SMS/WhatsApp conversation templates

---

**Last Updated:** 2026-04-29
