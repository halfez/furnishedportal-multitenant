# MTR Host Text Message Q&A Flow

**Format:** SMS/WhatsApp/Instagram DM text exchange  
**Duration:** 5-7 messages back-and-forth  
**Completion time:** 5-10 minutes (async-friendly)  
**Goal:** Test all 3 sub-wedges + validate WTP without requiring a live call

---

## Text Flow Design Principles

1. **Keep messages short** — Max 2-3 sentences per message (mobile-friendly)
2. **Ask one question at a time** — Don't overwhelm with multiple questions in one message
3. **Easy to answer** — Yes/no, 1-2 sentence responses, or simple numbers
4. **Conversational tone** — Write like you're texting a friend, not conducting a survey
5. **Respect async nature** — They might answer over hours/days, so each message should stand alone
6. **Use emojis sparingly** — A few emojis can make it feel warm, but don't overdo it

---

## Text Flow Template A: Tool Fragmentation Focus

### Message 1: Intro + Permission

**You:**
> Hey [Name]! Thanks for being open to this. I'm researching how MTR hosts manage operations — should take us 5-7 quick texts back and forth. Sound good?

**Expected response:** "Yes" / "Sure" / "Go for it"

---

### Message 2: Context (Sub-Wedge A Setup)

**You:**
> Perfect! Quick question — when a booking gets confirmed, how many different tools do you touch before the guest checks in? (PMS, messaging app, smart lock, cleaning scheduler, etc.)

**Expected response:** A number (e.g., "5" or "Like 6-7")

**What you're listening for:** 
- 3-5 tools = Moderate fragmentation
- 6+ tools = High fragmentation (strong wedge signal)

---

### Message 3: Pain Intensity (Sub-Wedge A)

**You:**
> Got it — so [their number] tools. What's the most annoying part of juggling all those?

**Expected response:** 1-2 sentence description (e.g., "Copying info between apps" or "Remembering which system to update")

**What you're listening for:**
- Emotion words ("annoying," "frustrating," "waste of time")
- Specific pain points ("copy-pasting," "switching apps," "things fall through cracks")

---

### Message 4: Corporate Inquiry (Sub-Wedge B)

**You:**
> Makes sense. Different topic — do you ever get inquiries from corporate clients or travel coordinators (relocation companies, consulting firms, etc.)?

**Expected response:** "Yes" / "No" / "Sometimes"

**Branch logic:**

**If YES or SOMETIMES:**

**You (Message 5a):**
> Interesting! Have any of them ghosted you after the initial inquiry? Like, they asked about your place but never booked?

**Expected response:** "Yes" / "Yeah, a few times" / "All the time" / "No"

**What you're listening for:**
- If they say "Yes" → Follow up: "Any idea why? Did they say anything?"
- If they say "No" → Skip to Message 6

---

**If NO:**

**You (Message 5b):**
> Got it. Would you *want* corporate bookings, or are you happy with your current guest mix?

**Expected response:** "I'd love to get them" / "Tried but it didn't work" / "Not really interested"

**What you're listening for:**
- "I'd love to" or "Tried but failed" = Validates wedge
- "Not interested" = Wedge doesn't apply

---

### Message 5: Airbnb Shift (Sub-Wedge C)

**You:**
> One more thing — have you shifted away from Airbnb toward longer-term MTR stays, or still doing short-term?

**Expected response:** "Yeah, I moved to MTR" / "Mix of both" / "Still mostly STR"

**Branch logic:**

**If they shifted to MTR:**

**You (Message 6a):**
> Nice! What made you make that shift? (Just curious what drove the decision.)

**Expected response:** 1-2 sentences (e.g., "Airbnb fees were killing me" / "Wanted more stability" / "Regulation changes")

**What you're listening for:**
- Airbnb fee pain, regulation fear, burnout from turnover, desire for stability

---

**If still doing STR:**

**You (Message 6b):**
> Got it. Ever thought about going full MTR, or happy with the STR model?

**Expected response:** "Thought about it" / "Maybe eventually" / "Nah, STR works for me"

**What you're listening for:**
- "Thought about it" = Potential wedge
- "Nah, STR works" = Wedge doesn't apply

---

### Message 6: Willingness to Pay

**You:**
> Last question, I promise 😅 — if there was a tool that eliminated your biggest operational headache, what would you pay per month per property? Ballpark is fine.

**Expected response:** A number (e.g., "$25" / "$50" / "Maybe $30?" / "Nothing really")

**What you're listening for:**
- $25+ = Willing to pay, pain is real
- $10-20 = Lukewarm
- "Nothing" or "Not sure" = Pain isn't acute enough

---

### Message 7: Wrap + Follow-Up Offer

**You:**
> Awesome, super helpful! If I end up building something based on all this research, would you want early access or beta testing?

**Expected response:** "Sure!" / "Yeah, keep me posted" / "Maybe" / "Nah, I'm good"

**You (final message):**
> Perfect — really appreciate your time, [Name]. If you think of anything else, feel free to shoot me a text. And if you know any other MTR hosts who'd be down to chat, I'd love an intro! 🙏

---

## Text Flow Template B: Corporate Credibility Focus

Use this variant when you know they get corporate inquiries (from research or their reply to your outreach).

### Message 1: Intro + Permission

**You:**
> Hey [Name]! Thanks for being open to this. I'm researching how MTR hosts handle corporate bookings — just need 5-7 quick texts from you. Cool?

**Expected response:** "Yes" / "Sure" / "Go ahead"

---

### Message 2: Corporate Inquiry Frequency (Sub-Wedge B Setup)

**You:**
> Quick one — how often do you get inquiries from corporate clients or travel coordinators? (Ballpark: few per month, few per year, all the time?)

**Expected response:** A frequency (e.g., "5-10 per month" / "Couple per quarter" / "Rarely")

**What you're listening for:**
- High frequency = They have deal flow to lose
- Low frequency = Wedge might not be acute

---

### Message 3: Conversion Rate (Sub-Wedge B)

**You:**
> Got it. And out of those inquiries, what percentage actually book? Like, do most convert or do a lot ghost?

**Expected response:** A percentage or ratio (e.g., "Maybe 30%" / "Half?" / "Most of them")

**What you're listening for:**
- Low conversion (<50%) = Strong wedge signal
- High conversion (>70%) = Wedge might not apply

---

### Message 4: Lost Deal Root Cause (Sub-Wedge B)

**You:**
> Interesting. For the ones that don't book, do you have any idea why? Did they say anything, or just disappear?

**Expected response:** 1-2 sentences (e.g., "They wanted invoicing" / "Said it looked too much like Airbnb" / "No idea, they ghosted")

**What you're listening for:**
- Feature requests ("portal," "invoicing," "reporting")
- Professionalism concerns ("didn't look legit," "wanted something more corporate")
- Price (less relevant to this wedge)

---

### Message 5: Feature Gap Awareness (Sub-Wedge B)

**You:**
> Have corporate clients ever asked you for features you don't have? Like online booking, invoicing, consolidated billing, etc.?

**Expected response:** "Yes" + list of features / "No" / "Not really"

**What you're listening for:**
- If "Yes" → Validates wedge strongly
- Specific features = Your product roadmap

---

### Message 6: Willingness to Pay (Corporate-Specific Framing)

**You:**
> Last thing — if there was a tool that made you look more "corporate-ready" and helped convert those inquiries, what would you pay per month per property?

**Expected response:** A number (e.g., "$50" / "$100" / "Not sure" / "$25?")

**What you're listening for:**
- $50+ = Strong signal (corporate bookings are high-value)
- $25-50 = Moderate signal
- <$25 = Weak signal

---

### Message 7: Wrap + Follow-Up Offer

**You:**
> Super helpful, thanks! If I build something based on this, would you want early access?

**Expected response:** "Sure!" / "Yeah" / "Maybe" / "Nah"

**You (final message):**
> Awesome — appreciate your time, [Name]! If you know any other hosts dealing with corporate clients, I'd love to chat with them too. 🙏

---

## Text Flow Template C: Airbnb Refugee Focus

Use this variant when you know they've shifted from STR to MTR (from research or outreach response).

### Message 1: Intro + Permission

**You:**
> Hey [Name]! Thanks for being open to this. I'm researching hosts who've shifted from STR to MTR — just need 5-7 quick texts. That work?

**Expected response:** "Yep" / "Sure" / "Go for it"

---

### Message 2: Migration Confirmation (Sub-Wedge C Setup)

**You:**
> Cool! So you were on Airbnb before and shifted to MTR, right? Just confirming I have that right.

**Expected response:** "Yeah" / "Yep, made the switch in [year]" / "Mostly, still do some STR"

---

### Message 3: Migration Driver (Sub-Wedge C)

**You:**
> What made you make that switch? Was it fees, regulation, burnout, something else?

**Expected response:** 1-2 sentences (e.g., "Airbnb fees were insane" / "Local regs cracked down" / "Wanted stable income")

**What you're listening for:**
- Airbnb fee pain (strong signal)
- Regulation fear (strong signal)
- Burnout from turnover (strong signal)
- Guest quality issues (moderate signal)

---

### Message 4: Transition Pain (Sub-Wedge C)

**You:**
> Makes sense. What's been the hardest part about transitioning from STR to MTR?

**Expected response:** 1-2 sentences (e.g., "Finding corporate tenants" / "Pricing differently" / "My tools are built for STR")

**What you're listening for:**
- "Tools are built for STR" = Validates tool wedge
- "Finding tenants" = Different problem (lead gen, not ops)
- "Screening" = Different problem (risk management)

---

### Message 5: Tool Fragmentation (Sub-Wedge A)

**You:**
> Random question — how many tools are you using now to manage a booking from confirmation to checkout?

**Expected response:** A number (e.g., "5" / "Too many lol" / "6-7")

**What you're listening for:**
- High tool count (6+) = Fragmentation wedge applies
- Low tool count (<4) = Fragmentation wedge might not apply

---

### Message 6: Willingness to Pay (Airbnb Refugee Framing)

**You:**
> Last one — if there was a tool built specifically for MTR hosts (not repurposed STR software), what would you pay per month per property?

**Expected response:** A number (e.g., "$30" / "$50" / "Depends on what it does" / "Not sure")

**What you're listening for:**
- $30+ = Willing to pay for MTR-specific tooling
- <$20 = Lukewarm
- "Not sure" = Need more value clarity

---

### Message 7: Wrap + Follow-Up Offer

**You:**
> Perfect, thanks! If I build something MTR-specific, want early access?

**Expected response:** "Yeah!" / "Sure" / "Maybe"

**You (final message):**
> Awesome — appreciate your time, [Name]! If you know other hosts who've made the STR → MTR shift, I'd love to chat with them too. 🙏

---

## Response Handling Tips

### If they reply with a question instead of answering:

**Them:** "What's this for again?"

**You:** "I'm researching operational pain points for MTR hosts. I run a couple properties in San Antonio and kept hitting the same issues, so I'm seeing if it's just me or a pattern. Your insights help a ton!"

---

### If they give a vague answer:

**Them:** "It's fine I guess."

**You:** "Haha 'fine' as in no issues, or 'fine' as in you're dealing with it but it's annoying?"

**Key principle:** Gently probe for specifics without being pushy.

---

### If they stop responding mid-conversation:

Wait 24-48 hours, then send:

**You:** "No worries if you're busy! If you have a sec to answer the last question that'd be awesome, but totally understand if not. Appreciate the time either way!"

**Don't:** Send multiple follow-ups or guilt-trip them.

---

### If they ask to jump on a call instead:

**Them:** "This is easier to explain on a call — can we chat?"

**You:** "Absolutely! Does [Day] at [Time] work? I'll call you. Should only take 10-15 min."

**Key principle:** If they prefer a call, accommodate. It's a signal of high engagement.

---

## Text Q&A Success Metrics

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| **Completion Rate** | >70% | Questions are easy to answer + you're not asking too much |
| **Avg Response Time** | <6 hours | They're engaged and the topic is relevant |
| **Verbatim Quote Yield** | ≥2 quotes | You're capturing pain in their own words |
| **WTP Disclosure** | >80% | They're comfortable with the format + trust you |
| **Follow-up opt-in** | >40% | They're interested in the solution |

If below targets:
- **Low completion rate** → Questions are too hard or too many
- **Slow response time** → Topic isn't urgent or you're not targeting the right people
- **No quotes** → Answers are too short; probe more
- **Low WTP disclosure** → Framing is off or trust isn't there

---

## Multi-Day Text Flow Strategy

If the conversation spans multiple days (common with async text), use these bridging messages:

### Day 2 Bridge (if they haven't responded in 24 hours):

**You:** "Hey [Name] — no rush on this! Just bumping in case it got buried. Whenever you have a sec to answer that last Q, I'd appreciate it!"

---

### Day 3 Wrap (if they've answered most but not all):

**You:** "Thanks for the answers so far, [Name]! If you don't have time for the last couple Qs, no worries — what you've shared already is super helpful. 🙏"

**Key principle:** Give them an out. Don't make them feel obligated.

---

## Converting Text Respondents to Call Interviews

If their text responses reveal strong pain signals, convert them to a call:

**After Message 5 or 6:**

**You:** "This is super helpful. Would you be open to a quick 10-min call to dive a bit deeper? I can work around your schedule — phone or Zoom, whatever's easier."

**Criteria for suggesting a call:**
- High tool count (6+)
- Strong emotion in their answers
- Mentioned lost deals or specific pain
- WTP ≥$50

---

## Text Capture Template

Use this to organize responses (copy into a spreadsheet or note-taking app):

```
TEXT Q&A CAPTURE SHEET
Date: ___________
Name: ___________
Phone/DM: ___________

Q1: Tool count: ___
Q2: Most annoying part: "___________"
Q3: Corporate inquiries: YES / NO / SOMETIMES
    - Conversion rate: ___%
    - Why they don't book: "___________"
Q4: Airbnb shift: YES / NO
    - Reason: "___________"
    - Transition pain: "___________"
Q5: WTP: $___ /month per property
Q6: Beta interest: YES / MAYBE / NO

PAIN SIGNALS:
- Tool fragmentation: High / Medium / Low
- Corporate credibility: High / Medium / Low
- Airbnb refugee: High / Medium / Low

FOLLOW-UP ACTION:
[ ] Convert to call (high intent)
[ ] Add to nurture list (lukewarm)
[ ] Skip (not a real buyer)

BEST QUOTE: "___________"
```

---

## Synthesizing Text Q&A Results

After 15-20 text conversations, analyze:

1. **Completion rate by template:** Which template (A, B, or C) gets the highest completion?
2. **Wedge frequency:** Which sub-wedge comes up most often?
3. **Avg WTP:** What's the median willingness to pay?
4. **Common language patterns:** What words/phrases do they use repeatedly?
5. **Drop-off point:** Where do people stop responding? (Signals a bad question or too much friction)

**Decision criteria:**
- If completion rate >70% + WTP ≥$30 → Text Q&A is working, keep using it
- If completion rate <50% → Questions are too hard or too many; simplify
- If WTP <$20 across most respondents → Pain isn't acute enough to monetize

---

## Advantages of Text Q&A vs. Call or Survey

| Dimension | Text Q&A | Call | Survey |
|-----------|----------|------|--------|
| **Response rate** | High (30-50%) | Medium (10-20%) | Medium (15-25%) |
| **Depth of insight** | Medium (can probe 1-2 times) | High (can go deep) | Low (no probing) |
| **Time commitment** | Low (5-10 min async) | Medium (15 min live) | Low (3 min) |
| **Verbatim quote quality** | High (conversational) | Highest (spoken emotion) | Medium (written) |
| **Scalability** | Medium (manual, but async) | Low (requires live time) | High (automated) |

**Use text Q&A when:**
- Prospect is busy and can't commit to a call
- You want higher response rate than email survey
- You want conversational depth without scheduling friction
- You're targeting mobile-first users (Instagram, WhatsApp)

---

## Key Principles

1. **One question at a time** — Don't overwhelm
2. **Easy to answer** — Yes/no or 1-2 sentences max
3. **Branch logic** — Adapt based on their answers
4. **Respect async** — Don't expect instant replies
5. **Probe gently** — If they give vague answers, ask for specifics (but don't interrogate)
6. **Capture quotes** — Copy-paste their exact words into your notes
7. **Convert high-intent to calls** — Text is great for screening; calls are great for depth
