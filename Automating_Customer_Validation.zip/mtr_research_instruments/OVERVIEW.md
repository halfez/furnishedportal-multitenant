# MTR Host Customer Validation Research Instruments — Complete Toolkit

## What You Have

This toolkit provides **everything you need** to validate customer pain points for MTR (Medium-Term Rental) hosts using proven customer development methodologies (SPIN Selling, Mom Test principles, and qualitative research best practices).

---

## 📁 Files Included

### Core Research Instruments (4)

1. **`outreach_dm_template.md`** — Initial Contact
   - 4 template variants (Tool Fragmentation, Corporate Credibility, Airbnb Refugee, General)
   - 3 personalization tiers (Deep, Segment, Template)
   - Channel-specific guidance (Instagram, LinkedIn, Facebook, Email)
   - Subject line A/B test variants
   - Response handling scripts

2. **`survey_template.md`** — 3-Minute Survey
   - Google Forms setup instructions (10 questions, <3 min)
   - Standalone HTML version (`survey_template.html`)
   - Tests all 3 sub-wedges
   - Willingness-to-pay question
   - Response analysis framework

3. **`call_script.md`** — 15-Minute SPIN Interview
   - Complete SPIN framework (Situation → Problem → Implication → Need-Payoff)
   - Interview notes template
   - Post-call debrief checklist
   - Verbatim quote capture prompts
   - Success metrics

4. **`text_qa_flow.md`** — Async Text/SMS Conversations
   - 3 conversation templates (5-7 messages each)
   - Tests all 3 sub-wedges
   - SMS/WhatsApp/Instagram DM friendly
   - Response handling tips
   - Multi-day conversation strategies

---

### Supporting Documents

5. **`README.md`** — Master Guide (24,000+ words)
   - When to use each instrument (decision tree)
   - Personalization strategy (3 tiers)
   - Response organization system
   - **Synthesis framework** → Path to "Definition of Done"
   - Common pitfalls and how to avoid them
   - Quality control checklist

6. **`QUICK_START.md`** — Get Started in 15 Minutes
   - Step-by-step first actions
   - Daily workflow
   - First week goals
   - Red flags and green flags

7. **`outreach_tracker_template.csv`** — Data Tracking
   - Pre-configured columns for all key metrics
   - Example entries included
   - Ready to import into Excel/Sheets

---

## 🎯 What Problem This Solves

You're testing **3 sub-wedges** to see which pain point is most acute for MTR hosts:

### Sub-Wedge A: Tool Fragmentation Post-Booking
**Hypothesis:** Hosts juggle 5-7+ tools to manage a single booking from confirmation to checkout, leading to manual data entry, context switching, and errors.

**Validation criteria:** ≥60% mention using 6+ tools + describe specific friction (copy-pasting, switching apps, things falling through cracks)

---

### Sub-Wedge B: Corporate Credibility Loss
**Hypothesis:** Hosts lose corporate bookings because they lack professional booking infrastructure (portal, invoicing, reporting).

**Validation criteria:** ≥60% have corporate inquiry experience + ≥30% lost deals + mentioned feature gaps (portal, invoicing, net-30 terms)

---

### Sub-Wedge C: Airbnb Refugee
**Hypothesis:** Hosts shifting from STR to MTR struggle with tools built for short-term rentals, plus Airbnb fee pain and regulation fear drove the migration.

**Validation criteria:** ≥40% shifted from Airbnb + articulated transition pain (tool mismatch, finding tenants, pricing)

---

## 🚀 How to Use This Toolkit

### Step 1: Start with QUICK_START.md
Read `QUICK_START.md` (7-minute read) to understand the **first actions** to take.

**Quick summary:**
1. Choose 10 targets
2. Personalize outreach using `outreach_dm_template.md`
3. Send messages
4. Respond with appropriate instrument (survey/call/text)
5. Track in `outreach_tracker_template.csv`

---

### Step 2: Choose Your Instrument Based on Response

| They said... | Use this... | File to reference |
|-------------|-------------|-------------------|
| "Send me a survey" | 3-Minute Survey | `survey_template.md` |
| "Let's do a call" | 15-Min SPIN Call | `call_script.md` |
| "Text works" | Async Text Q&A | `text_qa_flow.md` |

---

### Step 3: Capture and Track

After each conversation:
1. Update `outreach_tracker_template.csv` with:
   - Pain intensity (1-10)
   - Primary wedge (A/B/C)
   - WTP ($/month per property)
   - Beta interest (Yes/Maybe/No)
2. Save verbatim quotes
3. Note follow-up actions

---

### Step 4: Synthesize After 5, 15, and 30 Responses

Follow the **synthesis framework** in `README.md`:

**After 5 responses:**
- Calculate early wedge frequency
- Check median WTP
- Decide: Continue or pivot?

**After 15-20 responses:**
- Validate winning wedge
- Create `wedge_validation_summary.md`
- Analyze WTP distribution

**After 30+ responses:**
- Final synthesis
- Lock in positioning and pricing
- Create MVP spec

---

## 📊 Key Methodologies Applied

### SPIN Selling (from `conversation_skills/sales/SKILL.md`)

All instruments follow the SPIN framework:
1. **Situation** — Establish context (current workflow, tech stack)
2. **Problem** — Uncover pain (tool juggling, lost deals, transition struggles)
3. **Implication** — Quantify cost (time × $, lost deals, opportunity cost)
4. **Need-Payoff** — Let them describe the ideal solution and what they'd pay

**Critical rule:** Never pitch a solution before completing Problem and Implication stages.

---

### Customer Validation Best Practices (from `conversation_skills/marketing/SKILL.md`)

- **A/B Testing:** Multiple outreach template variants to optimize response rate
- **Segmentation:** 3 personalization tiers (Deep, Segment, Template) based on target quality
- **Funnel Metrics:** Track response rate, completion rate, WTP disclosure, beta opt-in
- **Qualitative Research:** Verbatim quote capture, open-ended questions, probing

---

### Mom Test Principles

- Talk about **their life**, not your idea
- Ask about **specifics in the past**, not generics or opinions about the future
- **Talk less, listen more**
- Avoid leading questions
- Validate interest with commitment (WTP, beta sign-up), not just "sounds interesting"

---

## ✅ Definition of Done (Customer Validation Complete)

You've completed validation when you can answer these **5 questions** with confidence:

1. **Is the pain real?**
   - ✓ ≥70% articulate quantified pain (time or money)

2. **Which wedge is strongest?**
   - ✓ One sub-wedge appears in ≥60% of conversations

3. **Is the pain acute?**
   - ✓ ≥50% rate pain ≥7/10
   - ✓ ≥40% express urgency ("I need this now")

4. **Will they pay?**
   - ✓ Median WTP ≥$30/month per property
   - ✓ ≥50% willing to pay $26+

5. **What should we build?**
   - ✓ Feature requests cluster around 3-5 themes
   - ✓ Clear MVP articulated

**If all 5 are YES:** ✅ Proceed to MVP scoping and build.

**If any are NO:** Iterate (more responses, pivot wedge, or change target segment).

---

## 📈 Success Metrics to Track

| Metric | Target | What It Tells You |
|--------|--------|-------------------|
| **Outreach Response Rate** | >15% | Message resonates with target audience |
| **Survey Completion Rate** | >60% | Questions are clear and quick |
| **Call Completion Rate** | 100% | (All scheduled calls should happen) |
| **Text Completion Rate** | >70% | Questions are easy to answer async |
| **Verbatim Quote Yield** | ≥3 per response | Capturing real pain in their words |
| **WTP Disclosure Rate** | >80% | Trust is high, question is clear |
| **Beta Interest Rate** | >30% | Solution resonates, urgency is real |

---

## 🎓 What Makes This Toolkit Different

### 1. Based on Proven Frameworks
- **SPIN Selling** for structured discovery
- **Mom Test** for unbiased validation
- **Marketing funnel metrics** for tracking and optimization

### 2. Multi-Format for Different Preferences
- Not everyone wants a call
- Offering 4 formats (call/Zoom/text/survey) increases response rate ~40%

### 3. Tests All 3 Wedges Systematically
- Every instrument probes all 3 sub-wedges
- Avoids confirmation bias (you're not just looking for one answer)

### 4. Quantifies Pain and WTP
- Not just "do you have this problem?"
- Forces quantification: hours/month, $/month, lost deals

### 5. Synthesis Framework Included
- Most validation guides tell you how to ask questions
- This toolkit tells you **when you're done** and **what to do next**

---

## 🛠 Customization Guide

These are **starting points**, not rigid scripts. Adapt them to your needs:

### Modify the Sub-Wedges
If you want to test different pain points:
1. Replace Sub-Wedge A, B, or C with your hypothesis
2. Update questions in `survey_template.md`, `call_script.md`, `text_qa_flow.md`
3. Keep the structure (Situation → Problem → Implication → Need-Payoff)

### Adjust the Format
- **Shorter calls?** Cut Situation to 1 min, keep Problem and Implication
- **Longer survey?** Add 2-3 more open-ended questions (but test completion rate)
- **Fewer texts?** Condense to 3-4 messages, focus on one wedge

### Change the Target Audience
This toolkit is for **MTR hosts**, but the methodology works for any B2B/B2C customer validation:
- Replace "MTR host" with your persona
- Replace "tool fragmentation" with your wedge hypothesis
- Keep the SPIN structure and metrics

---

## 📚 Additional Resources Referenced

### From `conversation_skills/sales/SKILL.md`
- SPIN Selling methodology (Situation, Problem, Implication, Need-Payoff)
- MEDDIC/BANT scoring frameworks
- Prospecting workflows and outreach cadence
- Lead qualification criteria

### From `conversation_skills/marketing/SKILL.md`
- Marketing funnel (AARRR: Awareness, Acquisition, Activation, Revenue, Retention, Referral)
- Messaging & positioning framework
- Brand voice & tone matrix
- A/B testing methodology
- Email subject line optimization

---

## 🚦 Traffic Light System for Validation Progress

Use this simple guide to know where you stand:

### 🟢 GREEN LIGHT — Keep Going
- Response rate >20%
- Completion rate >60%
- ≥60% mention the same pain
- Median WTP ≥$30
- People ask "When can I sign up?"

**Action:** Continue to 30+ responses for final validation.

---

### 🟡 YELLOW FLAG — Adjust Course
- Response rate 10-20%
- Completion rate 40-60%
- Mixed wedge signals (no clear winner)
- Median WTP $15-25
- Some interest but no urgency

**Action:** Refine questions, increase personalization, or narrow target segment.

---

### 🔴 RED FLAG — Pivot or Stop
- Response rate <10%
- Completion rate <40%
- Majority say "no real pain"
- Median WTP <$10
- No consistent wedge

**Action:** Pivot hypothesis, change target segment, or abandon this problem space.

---

## 🎯 Next Steps After Validation

Once you hit **Definition of Done**, proceed to:

1. **MVP Scoping** (Use verbatim quotes and feature requests to define must-haves)
2. **Positioning & Messaging** (Use exact language from hosts for landing page copy)
3. **Beta Recruitment** (Reach out to hosts who opted in for early access)
4. **Build & Iterate** (Ship MVP, measure if it actually solves the pain)

**Reference:** See "Next Steps After Validation" section in `README.md` for detailed guidance.

---

## 📞 Support & Questions

**Stuck on something?**
- Re-read the relevant instrument file (`outreach_dm_template.md`, `call_script.md`, etc.)
- Check "Common Pitfalls" in `README.md`
- Review the sales and marketing skills for deeper methodology context

**Want to adapt this toolkit?**
- All templates are designed to be customized
- Keep the core structure (SPIN, Mom Test principles, metrics tracking)
- Test your modifications on 3-5 responses before scaling

---

## 📦 What's in the Box

### Files (19 total)

#### Research Instruments (Core)
- ✅ `outreach_dm_template.md` (+ PDF, DOCX)
- ✅ `survey_template.md` (+ PDF, DOCX)
- ✅ `survey_template.html`
- ✅ `call_script.md` (+ PDF, DOCX)
- ✅ `text_qa_flow.md` (+ PDF, DOCX)

#### Guides & Templates
- ✅ `README.md` — Master guide (24,000+ words)
- ✅ `QUICK_START.md` (+ PDF, DOCX) — Get started in 15 min
- ✅ `OVERVIEW.md` (this file) — Toolkit summary
- ✅ `outreach_tracker_template.csv` — Data tracking spreadsheet

#### Auto-Generated (for convenience)
- ✅ PDF versions of all markdown files
- ✅ DOCX versions of all markdown files

**Total file size:** ~460KB (lightweight, portable, easy to share)

---

## 🏆 Success Stories (Hypothetical Use Cases)

### Use Case 1: Solo Founder
**Goal:** Validate MTR host pain before building MVP

**Approach:**
- Week 1: Send 30 outreach DMs (Template A + D mix)
- Week 2: Complete 10 surveys + 5 calls
- Week 3: Synthesize, validate Sub-Wedge B (Corporate Credibility)
- Week 4: Create MVP spec, recruit 8 beta users

**Result:** Validated $75/month WTP, built MVP, closed 5 paying customers in 60 days.

---

### Use Case 2: Startup Team
**Goal:** Decide which wedge to focus on for GTM strategy

**Approach:**
- Month 1: Run 50 outreach campaigns (all 3 wedges tested)
- Month 2: Completed 40 interviews (20 calls, 15 texts, 5 surveys)
- Synthesis: Sub-Wedge A (Tool Fragmentation) = 65% frequency, $50 median WTP

**Result:** Locked in positioning ("Stop juggling 7 tools"), built tool consolidation product, raised pre-seed round.

---

### Use Case 3: Corporate Innovation Team
**Goal:** Explore MTR market for new product line

**Approach:**
- Deployed 3 team members, each testing one wedge
- 100 total outreach, 60 responses, 30 deep interviews
- Cross-compared wedge performance

**Result:** Discovered Sub-Wedge B (Corporate Credibility) had highest WTP ($100+) but smallest TAM. Pivoted to Sub-Wedge A for broader market.

---

## 🎓 Educational Value

Even if you don't use this toolkit for MTR hosts, you'll learn:
- How to conduct unbiased customer validation interviews (SPIN framework)
- How to quantify willingness to pay (not just "would you buy this?")
- How to synthesize qualitative research into actionable insights
- How to avoid confirmation bias and happy ears
- How to track and measure customer development progress

**These skills transfer to ANY customer validation project.**

---

## 📅 Timeline Expectations

### Realistic Timeline for Complete Validation

| Phase | Duration | Output |
|-------|----------|--------|
| **Setup** | 1-2 hours | Targets identified, outreach personalized |
| **Initial Outreach** | 1 week | 20-30 messages sent, 5-10 responses |
| **First 5 Interviews** | 1 week | Early wedge signal, pivot/continue decision |
| **15-20 Interviews** | 2-3 weeks | Winning wedge validated, WTP confirmed |
| **30+ Interviews** | 4-6 weeks | Final synthesis, MVP spec, beta recruitment |

**Total:** 6-8 weeks from zero to validated, ready to build.

**Faster track (if high response rate):** 3-4 weeks.

---

## ⚡ Power Tips

1. **Personalization matters:** Tier 1 outreach gets 2-3x response rate of Tier 3
2. **Offer multiple formats:** Increases response rate ~40%
3. **Follow up once:** After 3 days, one follow-up, then move on
4. **Verbatim quotes are gold:** Capture exact words for positioning and copy
5. **Quantify everything:** Time cost, money cost, WTP — numbers > opinions
6. **Synthesize early:** After 5 responses, check for signal (don't wait till 30)
7. **Beta list is your MVP:** Hosts who opt in = your first customers

---

## 🙏 Acknowledgments

**Frameworks Applied:**
- SPIN Selling (Neil Rackham)
- The Mom Test (Rob Fitzpatrick)
- Marketing funnel metrics (AARRR)
- Qualitative research best practices

**Skills Referenced:**
- `conversation_skills/sales/SKILL.md`
- `conversation_skills/marketing/SKILL.md`

---

**You're ready to start validating! 🚀**

**First step:** Open `QUICK_START.md` and complete Step 1 (Choose Your First 10 Targets).

**Good luck!**

---

**Last Updated:** 2026-04-29  
**Version:** 1.0  
**License:** Use freely, adapt as needed
