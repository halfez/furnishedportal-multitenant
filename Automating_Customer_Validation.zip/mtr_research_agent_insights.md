# Key Insights from Marketing & Sales Skills — Applied to MTR Host Research & CRM

## 1. Finding & Researching MTR Hosts → ICP Definition + Lead Qualification

### ICP (Ideal Customer Profile) Framework — Adapted for MTR Hosts

The **Sales skill** prescribes defining the ICP across four dimensions before any outreach. Applied to mid-term rental hosts:

| Dimension | MTR Host Application |
|-----------|---------------------|
| **Firmographics** | Number of listings, property types (furnished apartments, corporate housing), markets served, listing platforms (Furnished Finder, Airbnb, VRBO), solo operator vs. property management company |
| **Behavioral Signals** | Recently added new listings, expanding to new markets, hiring cleaners/VAs, attending STR/MTR conferences, active in Facebook groups or BiggerPockets |
| **Pain Indicators** | Vacancies visible on listing sites, complaints about guest quality, pricing inconsistencies, no direct booking site, manual processes |
| **Negative Filters** | Hosts with only 1 listing and no growth intent, resort/vacation-only operators, hosts outside target geography |

### Lead Scoring — 0–100 Scale (from Sales skill)

| Category (Weight) | MTR Host Criteria |
|-------------------|-------------------|
| **Fit (30%)** | Matches ICP: multi-property, target market, mid-term focus |
| **Intent (30%)** | Signals of growth or pain: new listings, social media complaints, seeking tools |
| **Engagement (20%)** | Responded to outreach, opened emails, attended webinar, replied in DMs |
| **Timing (20%)** | Seasonal vacancy approaching, lease expiring, recently lost a booking platform |

> **Takeaway for the research agent:** Automate ICP matching by scraping listing platforms for property counts, pricing, availability gaps, and cross-referencing with social profiles. Each lead should enter the CRM pre-scored.

---

## 2. Cold Outreach Strategy → Multi-Channel Cadence + Personalization Tiers

### 21-Day Outreach Cadence — Adapted for MTR Hosts

The Sales skill defines a proven multi-channel cadence. Applied to MTR hosts:

| Day | Channel | Action |
|-----|---------|--------|
| **1** | Email | Personalized insight-led email — *no pitch*. Reference their specific listings, market, or a vacancy pattern you noticed. |
| **3** | Facebook/LinkedIn | Connection request or group comment with personalized note |
| **5** | Phone/SMS | First attempt — brief voicemail referencing the email |
| **7** | Email | Follow-up with a relevant case study or data point (e.g., "hosts in [market] are averaging X% higher occupancy with [approach]") |
| **10** | Social | Engage with their content — comment on a post, share their listing |
| **14** | Email | "Break-up" email offering standalone value (free market report, vacancy audit) |
| **21** | Email | Final touch — referral ask or offer to add to a long-term nurture list |

### Personalization Tiers (from Sales skill)

| Tier | Effort | When to Use for MTR Hosts |
|------|--------|---------------------------|
| **Tier 1 — Hyper** (15-20 min) | Top 50 whale accounts: hosts with 10+ properties, PM companies | Custom research on their portfolio, specific vacancy data, tailored ROI projection |
| **Tier 2 — Segment** (5-10 min) | ICP-match with intent signals | Market-specific pain, role-relevant metrics, mention a specific listing |
| **Tier 3 — Template** (1-2 min) | High-volume outbound | First name, market, number of listings, one relevant data point |

### Subject Line Principles (from both skills)

- Under 50 characters
- Reference **their world**: *"Your 3BR in Austin — vacancy idea"* beats *"Our platform demo"*
- Questions convert 22% higher: *"Filling gaps between tenants?"*
- No clickbait — direct and honest

### Email Personalization Checklist (from Sales skill)

For cold emails to MTR hosts, the **email generator template** (`cold-outreach`) expects:
- `prospect-name` — the host's name
- `company` — their PM company or portfolio name
- `pain-point` — e.g., "gaps between mid-term tenants" or "manual guest communication"

> **Takeaway for the CRM:** Store enriched fields per lead that map directly to outreach template variables: name, market, property count, identified pain, listing URLs.

---

## 3. Customer Validation Interviews → SPIN Selling + Discovery Framework

### SPIN Framework — Applied to MTR Host Interviews

The Sales skill's **SPIN Selling** methodology maps perfectly to customer validation:

| Stage | Example Questions for MTR Hosts |
|-------|--------------------------------|
| **Situation** (use sparingly — research first) | "How many properties are you managing right now? Which platforms do you list on?" |
| **Problem** | "What's your biggest challenge filling gaps between tenants?" / "How do you currently handle pricing across seasons?" |
| **Implication** | "When a unit sits vacant for 2 weeks, what does that cost you in mortgage + utilities?" / "How many hours a week do you spend on manual guest communication?" |
| **Need-Payoff** | "If you could cut vacancy by 50%, what would that mean for your annual revenue?" / "Would it be valuable to have one dashboard for all your listings?" |

> **Critical rule from the skill:** *"Never pitch until you have completed at least the Problem and Implication stages. Premature solutioning kills deals."*

### Call Preparation Checklist (from Sales skill)

Before every validation call with an MTR host:

1. **Research the person:** LinkedIn, BiggerPockets profile, Facebook group posts, podcast appearances
2. **Research the business:** Listing URLs, pricing, reviews, vacancy patterns, property conditions
3. **Formulate a hypothesis:** *"Based on their 4 listings in Denver with 2 currently vacant, I believe they're struggling with seasonal demand gaps costing them ~$3K/month."*
4. **Prepare 5 discovery questions:** At least 2 Problem, 2 Implication (SPIN)
5. **Define your ask:** What's the next step? (Second call, intro to another host, beta signup, testimonial)
6. **Prepare objection responses:** Top 3 anticipated pushbacks

### Validation-Specific Additions (from Marketing skill's audience research)

The Marketing skill emphasizes **audience segmentation** and **persona building**. For validation interviews, track:

- **Persona segments:** Solo host (1-3 units) vs. small PM (4-15) vs. mid-market PM (15-50)
- **Funnel stage of awareness:** Unaware of pain → Aware → Solution-seeking → Tool-evaluating
- **Behavioral data:** How they currently solve the problem (spreadsheets, gut feel, VA, existing software)
- **Quantified pain:** Always tie pain to a number — dollars lost, hours wasted, bookings missed

---

## 4. Lead Enrichment & Contact Data Gathering → Research Agent Design

### Data Points to Collect Per Lead

Combining both skills' frameworks, the research agent should enrich each MTR host record with:

#### From ICP/Firmographic Research (Sales skill)
| Field | Source Ideas |
|-------|-------------|
| Full name | Listing platforms, LinkedIn, business registrations |
| Email | Platform profiles, personal websites, WHOIS, Hunter.io |
| Phone | Business listings, direct booking sites, skip tracing |
| LinkedIn / Social profiles | LinkedIn search, Facebook group membership |
| Company / Brand name | Direct booking site, LLC registrations |
| Number of properties | Listing platform scraping, public records |
| Markets / Geographies | Listing addresses |
| Platforms used | Furnished Finder, Airbnb, VRBO, Booking.com presence |
| Property types | Furnished apartments, houses, corporate housing |
| Estimated revenue | Listing prices × estimated occupancy |
| Tech stack | Direct booking site technology, PMS software mentions |

#### From Pain/Intent Signals (Sales skill)
| Signal | How to Detect |
|--------|--------------|
| Vacancy gaps | Calendar availability on listing platforms |
| Pricing issues | Rate inconsistencies across platforms, below-market pricing |
| Poor reviews | Review scraping for complaints about communication, cleanliness, process |
| Manual operations | No PMS detected, no automated messaging, no dynamic pricing tool |
| Growth intent | New listings recently added, social posts about scaling |
| Community activity | Facebook group posts asking for advice, BiggerPockets threads |

#### From Positioning/Messaging (Marketing skill)
| Field | Purpose |
|-------|---------|
| Identified pain point | Maps to outreach template `pain-point` variable |
| Segment/tier | Determines personalization depth (Tier 1/2/3) |
| Best channel | Where they're most active (email, Facebook, LinkedIn, phone) |
| Content they've engaged with | Topics they post about — informs which case studies to send |

### Competitive Intelligence (Marketing skill)

The Marketing skill's **Competitive Analysis Framework** should be applied to understand what tools MTR hosts currently use:

- **Direct competitors:** Hospitable, Guesty, OwnerRez, Lodgify — features, pricing, weaknesses
- **Indirect alternatives:** Spreadsheets, VAs, manual processes
- **Switching signals:** Complaints about current tools in forums/reviews

> **Takeaway for the research agent:** Build a competitor detection module that identifies which PMS/tools a host currently uses (from website technology, social mentions, or direct ask during validation).

---

## 5. CRM Pipeline Design → Stage Definitions from Sales Skill

Map the Sales skill's pipeline stages to the MTR host journey:

| Stage | Entry Criteria | Exit Criteria | Probability |
|-------|---------------|---------------|-------------|
| **Researched** | ICP match confirmed, enriched in CRM | — | 0% |
| **Contacted** | First outreach sent | First meaningful reply received | 5% |
| **Discovery** | Pain identified in conversation | Pain quantified, next step agreed | 15% |
| **Validation** | Participated in validation interview | Confirmed problem-solution fit, willing to beta test | 30% |
| **Proposal / Beta** | Solution demonstrated | Active beta user or verbal commitment | 50% |
| **Negotiation** | Pricing discussed | Terms agreed | 75% |
| **Closed Won** | Signed up / paying | Revenue recognized | 100% |

### Forecasting Hygiene (from Sales skill)
- Any lead without activity in **14+ days** should be downgraded or re-engaged
- **Stale pipeline** is the #1 pitfall: *"Dead deals inflate forecasts and waste management's time"*
- Always **multi-thread** — connect with more than one person at a PM company

---

## 6. Messaging & Positioning (Marketing Skill) — Applied to MTR Outreach

### Positioning Statement Template

```
For [mid-term rental hosts managing 3+ properties] who [struggle with vacancy gaps and manual operations],
[Product] is a [tool/platform] that [reduces vacancy and automates guest management].
Unlike [spreadsheets / generic PMS tools], we [are purpose-built for the MTR niche].
```

### Proof Points to Develop Through Validation
1. **[X% vacancy reduction]** — backed by [beta user data]
2. **[Y hours/week saved]** — backed by [time-tracking study]
3. **[$Z additional annual revenue]** — backed by [case study]

### Content Tiers for Nurture (Marketing skill)
| Tier | MTR Application |
|------|-----------------|
| **Hero** (quarterly) | "State of Mid-Term Rentals" report, market data analysis |
| **Hub** (weekly) | Blog posts on MTR operations, pricing strategies, platform tips |
| **Hygiene** (daily) | Social posts, quick tips, template downloads, FAQ content |

---

## Summary: What This Means for the Research Agent & CRM

### Research Agent Must:
1. **Auto-classify** leads against the ICP definition (firmographics + signals)
2. **Score leads 0–100** using the four-category framework (Fit, Intent, Engagement, Timing)
3. **Enrich records** with all fields listed above — especially pain signals and contact data
4. **Detect competitors** — identify what tools each host currently uses
5. **Flag high-intent signals** — vacancies, growth activity, complaints — for priority outreach

### CRM Must:
1. **Store enriched lead data** mapped to outreach template variables
2. **Track pipeline stages** with clear entry/exit criteria
3. **Automate cadence tracking** — 21-day multi-channel sequence with status per step
4. **Support personalization tiers** — route Tier 1 leads to manual outreach, Tier 3 to automated sequences
5. **Enforce hygiene** — auto-flag leads stale for 14+ days
6. **Log validation insights** — SPIN-structured notes, quantified pain, segment classification

### Outreach Must:
1. **Lead with insight, not pitch** — reference their specific listings, market data, vacancy patterns
2. **Use SPIN for all calls** — never pitch before Problem + Implication stages are complete
3. **Multi-channel** — email + social + phone, not email-only
4. **Personalize by tier** — whale accounts get hyper-personalized, volume gets smart templates
5. **Track engagement signals** — opens, replies, social interactions feed back into lead score
