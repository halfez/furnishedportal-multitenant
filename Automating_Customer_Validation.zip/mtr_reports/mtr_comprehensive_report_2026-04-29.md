# MTR Customer Validation Research - Comprehensive Collection Report
**Date:** 2026-04-29  
**Markets:** Austin · Dallas · San Antonio · Houston  
**Total Hosts Collected:** 30  
**Research Purpose:** Customer validation of three sub-wedge hypotheses for MTR product development

---

## Executive Summary

This report documents the discovery and research-value scoring of **30 diverse MTR (Medium-Term Rental) hosts** across four Texas markets in a single comprehensive research session. Hosts were sourced from Google/web search, LinkedIn people search, and company website scraping. All hosts were scored on a 100-point research-value framework designed to validate three product sub-wedge hypotheses.

**Key Findings:**
- **30 hosts collected** across Austin (8), Dallas (8), San Antonio (7), Houston (7)
- **Diversity achieved:** none (4), landing_page (5), basic_site (11), full_portal (10) — good spread across tech sophistication levels
- **Strongest sub-wedge signal:** Corporate Credibility Loss — **26 of 30 hosts (87%)** show evidence of serving corporate/professional clients where image and reliability matter
- **Tool Fragmentation:** **13 of 30 hosts (43%)** explicitly use multiple disconnected tools
- **Airbnb Refugee:** **5 of 30 hosts (17%)** show signals of leaving or diversifying away from Airbnb
- **Top research-value host:** Mubeen Abbas / Urban Lights Residential (score: 80) — no website, corporate focus, multiple tool integrations
- **Best interview candidates:** 14 hosts have verified email or phone contact info

---

## All 30 Hosts Discovered

| # | Host Name | Business Name | Market | Website Type | Score | Email | Phone | Key Signals |
|---|-----------|---------------|--------|-------------|-------|-------|-------|-------------|
| 1 | Mubeen Abbas | Urban Lights Residential | Dallas | none | **80** | mubeen@urbanlightsresidential.com | 469-618-3041 | Tool Frag ✓, Corp Cred ✓ |
| 2 | Surge MTR Management | Surge | Austin | basic_site | **70** | hello@gowithsurge.com | 832-271-2125 | Tool Frag ✓, Corp Cred ✓ |
| 3 | Lorraine Fisher | Haven Furnished Stays | San Antonio | landing_page | **70** | — | 210-548-8579 | Tool Frag ✓, Corp Cred ✓ |
| 4 | Hope Sierra | Sierra Temporary Lodging | San Antonio | none | **70** | — | — | Corp Cred ✓ |
| 5 | Robert Gibbs | RoGi Properties LLC | Austin | basic_site | **65** | — | 512-710-5443 | Tool Frag ✓, Corp Cred ✓, Airbnb Ref ✓ |
| 6 | Chase Ivey | Wake Up In TEXAS | Dallas | basic_site | **65** | hello@wakeupintexas.com | 214-642-5637 | Tool Frag ✓, Corp Cred ✓, Airbnb Ref ✓ |
| 7 | Sylvia KeyBloom | KeyBloom Hosting | Dallas | basic_site | **65** | hello@keybloom.co | 973-337-9566 | Tool Frag ✓, Corp Cred ✓ |
| 8 | Kelsea Dallas Furnished | Dallas Furnished Homes | Dallas | landing_page | **65** | — | — | Corp Cred ✓ |
| 9 | Diane Berry | Murphy's Corporate Housing | Houston | landing_page | **65** | — | — | Corp Cred ✓ |
| 10 | Michael Smith | Alamo Corporate Housing Sales | San Antonio | none | **65** | alamocorporatesales@gmail.com | — | Corp Cred ✓ |
| 11 | CorpLofts Owner | CorpLofts | Houston | none | **60** | — | — | — |
| 12 | Lodgeur Houston | Lodgeur Incorporated | Houston | full_portal | **60** | — | — | Tool Frag ✓, Corp Cred ✓, Airbnb Ref ✓ |
| 13 | Jennifer Korb | Corporate Suites Texas | San Antonio | landing_page | **60** | — | 800-934-3980 | Corp Cred ✓ |
| 14 | Tracy Hayes | CWS Corporate Housing | Austin | full_portal | **55** | — | 512-953-1160 | Corp Cred ✓ |
| 15 | Jesse Shepp | Nabro Holdings LLC | Dallas | basic_site | **55** | — | — | Corp Cred ✓ |
| 16 | Amyfinehouse Dallas | Amyfinehouse | Dallas | full_portal | **55** | bookings@amyfinehouse.com | +14696428868 | Tool Frag ✓, Corp Cred ✓, Airbnb Ref ✓ |
| 17 | Comfy Houston | Comfortable Home Furnished Apts | Houston | basic_site | **55** | comfyhomesapts@gmail.com | 832-295-0588 | Corp Cred ✓ |
| 18 | Luxurway Houston | Luxurway | Houston | basic_site | **55** | — | — | Corp Cred ✓ |
| 19 | Pleasant Stay Houston | Pleasant Stay Corporate Housing | Houston | basic_site | **55** | — | — | Corp Cred ✓ |
| 20 | Premier Corporate Housing SA | Premier Corporate Housing | San Antonio | basic_site | **55** | — | 281-441-7700 | Corp Cred ✓ |
| 21 | Alamo Corporate Housing | Alamo Corporate Housing | San Antonio | full_portal | **55** | alamocorporatesales@gmail.com | 866-224-4200 | Corp Cred ✓, Airbnb Ref ✓ |
| 22 | Siena Wimberly | DECO Furnished Stays | Austin | full_portal | **50** | hello@staydeco.com | 877-872-5530 | Corp Cred ✓ |
| 23 | STR Management Austin | Short Term Rental Management LLC | Austin | full_portal | **50** | info@strmanagement.com | 844-646-8787 | Tool Frag ✓ |
| 24 | Guest Haus Rentals Team | Guest Haus Rentals | Austin | basic_site | **50** | info@guesthausrentals.com | 512-823-1286 | Tool Frag ✓ |
| 25 | Texas Corporate Homes | Texas Corporate Homes LLC | Austin | full_portal | **50** | hello@staytch.com | 214-831-4577 | Tool Frag ✓, Corp Cred ✓ |
| 26 | Ritzy Room Dallas | Ritzy Room | Dallas | full_portal | **50** | — | — | Corp Cred ✓ |
| 27 | Eduard Chepurnoy | Houston Corporate Housing | Houston | full_portal | **50** | — | 469-306-9811 | Tool Frag ✓, Corp Cred ✓ |
| 28 | Corporate Comforts SA | Corporate Comforts | San Antonio | basic_site | **50** | sales@corporatecomforts.com | 855-350-9999 | Corp Cred ✓ |
| 29 | Furnished Housing In Austin | Furnished Housing In Austin | Austin | landing_page | **45** | info@FurnishedHousingInAustin.com | 512-429-7829 | — |
| 30 | PBD Living Dallas | PBD Living | Dallas | full_portal | **45** | — | — | Tool Frag ✓, Corp Cred ✓ |

---

## Tech Sophistication Breakdown

| Website Type | Count | % | Markets Represented |
|-------------|-------|---|---------------------|
| **none** | 4 | 13% | Dallas (1), San Antonio (2), Houston (1) |
| **landing_page** | 5 | 17% | Austin (1), Dallas (1), San Antonio (2), Houston (1) |
| **basic_site** | 11 | 37% | Austin (3), Dallas (3), San Antonio (2), Houston (3) |
| **full_portal** | 10 | 33% | Austin (4), Dallas (3), San Antonio (2), Houston (3) |
| **TOTAL** | **30** | **100%** | All 4 markets |

**Analysis:** The distribution skews toward more sophisticated operators (basic_site + full_portal = 70%), which reflects the Texas MTR market's maturity. The 4 hosts with no website and 5 with landing pages represent the most underserved segment — operators who lack digital infrastructure and are prime candidates for product adoption. The `none` bucket is the most underrepresented and carries the highest diversity_value_score (40 pts each).

---

## Sub-Wedge Signal Distribution

| Hypothesis | Hosts with Signal | % | Strongest Evidence Examples |
|-----------|------------------|---|----------------------------|
| **(a) Tool Fragmentation** | 13 / 30 | **43%** | Surge (Airbnb + VRBO + Booking.com + Google VR + Furnished Finder + AI pricing + smart locks + owner portal); Mubeen Abbas (Greystar + Pinnacle + Post + UDR integrations); Chase Ivey (StayDirectly + Airbnb + insurance integrations) |
| **(b) Corporate Credibility Loss** | 26 / 30 | **87%** | CWS Corporate Housing (Deloitte, HP clients); Alamo Corporate Housing (explicitly compares to Airbnb's 90-day limit and "varying customer service"); Lodgeur (positions against "Airbnb fee uncertainty"); DECO (CCHP certified, Fortune 500 clients); Urban Lights (Toyota, Chase, Boeing, Liberty Mutual employees) |
| **(c) Airbnb Refugee Scramble** | 5 / 30 | **17%** | Robert Gibbs (started as Airbnb host May 2022, pivoted to MTR); Chase Ivey (started post-pandemic as Airbnb host, now diversifying to StayDirectly); Amyfinehouse (promotes direct booking to avoid 15% Airbnb fees); Lodgeur (explicitly positions against Airbnb fee uncertainty); Alamo Corporate Housing (explicitly positions against Airbnb 90-day max rule) |

**Key Insight:** Corporate Credibility Loss is the dominant signal (87%), suggesting this is the most validated sub-wedge. Tool Fragmentation is moderate (43%) and represents a strong product opportunity. Airbnb Refugee is the weakest signal (17%) but the 5 hosts who show it are highly articulate about their pain — making them excellent interview candidates.

---

## Top Research-Value Candidates (Ranked)

### 🥇 #1 — Mubeen Abbas / Urban Lights Residential (Score: 80)
**Market:** Dallas | **Website Type:** none (website broken/404)  
**Contact:** mubeen@urbanlightsresidential.com | 469-618-3041  
**Why Top Priority:** Highest diversity value (40 pts — fills the underrepresented "none" bucket). Has email AND phone. Explicitly targets Toyota, Chase, Boeing, Liberty Mutual employees — corporate credibility is existential. Works with Greystar, Pinnacle, Post, UDR properties — classic tool fragmentation across multiple property management systems. LinkedIn-active with posts about corporate housing availability.  
**Suggested Opener:** "I noticed you work with Greystar, Pinnacle, and UDR properties simultaneously — how do you manage the different systems and keep your corporate clients' experience consistent?"

### 🥈 #2 — Surge MTR Management (Score: 70)
**Market:** Austin | **Website Type:** basic_site  
**Contact:** hello@gowithsurge.com | 832-271-2125  
**Why High Priority:** Extensive blog content discussing MTR operations, challenges, and strategies (high articulation score). Uses 7+ tools: Airbnb, VRBO, Booking.com, Google Vacation Rentals, Furnished Finder, AI identity verification, dynamic pricing, smart locks, owner portal. Achieved Airbnb Superhost status. Texas-focused MTR specialist with deep operational knowledge.  
**Suggested Opener:** "Your blog on MTR property management in Texas is really detailed — you mention using Airbnb, VRBO, Furnished Finder, and corporate housing websites simultaneously. What's the biggest operational headache managing all those channels?"

### 🥉 #3 — Lorraine Fisher / Haven Furnished Stays (Score: 70)
**Market:** San Antonio | **Website Type:** landing_page  
**Contact:** 210-548-8579 (LinkedIn: lorrainefisher777)  
**Why High Priority:** Owner-operator with multiple businesses (Haven Furnished Stays + PREMIUM 360 TOURS + LUXE DESIGN INTERIORS). Manages both STR and MTR. Uses Google Sites for web presence — classic underserved operator. Serves corporate travelers, medical professionals, military. Active LinkedIn presence discussing MTR staging and design.  
**Suggested Opener:** "You're managing STR staging, MTR operations, and 360 tours simultaneously — how do you keep track of everything across your different businesses?"

### #4 — Hope Sierra / Sierra Temporary Lodging (Score: 70)
**Market:** San Antonio | **Website Type:** none  
**Contact:** LinkedIn only (hope-sierra-67657112)  
**Why High Priority:** 20+ years in corporate housing (Oakwood Worldwide, Nino Corporate Housing, Corporate Apartment Network). Certified partner with Nomad Temporary Housing. No website — relies entirely on relationships and LinkedIn. Specializes in executive-style accommodations. Deep industry knowledge, likely very articulate about pain points.  
**Suggested Opener:** "With 20+ years in corporate housing from Oakwood to running your own firm, what's changed most about how you find and manage clients today?"

### #5 — Robert Gibbs / RoGi Properties LLC (Score: 65)
**Market:** Austin | **Website Type:** basic_site  
**Contact:** 512-710-5443 (LinkedIn: robert-gibbs-a72a19198)  
**Why High Priority:** All three sub-wedge signals present. Started as Airbnb/STR host May 2022, explicitly pivoted to MTR. Uses TurboTenant, Furnished Finder, CHBO, hybrid pricing — tool fragmentation. Targets travel nurses, insurance claims, relocation — corporate credibility matters. Very active on LinkedIn with posts about MTR operations. Excellent interview candidate for Airbnb refugee narrative.  
**Suggested Opener:** "I saw your LinkedIn post about transitioning from STR to MTR — what made you make that shift, and what tools are you using now to manage the different platforms?"

### #6 — Chase Ivey / Wake Up In TEXAS (Score: 65)
**Market:** Dallas | **Website Type:** basic_site  
**Contact:** hello@wakeupintexas.com | 214-642-5637  
**Why High Priority:** All three sub-wedge signals present. Started as Airbnb host post-pandemic (when other business was "non-essential"), became Superhost, now diversifying to StayDirectly platform. 250+ homes, 1,000+ completed stays, 4.98 rating. Serves displaced families and insurance clients. Uses StayDirectly + Airbnb + insurance integrations.  
**Suggested Opener:** "You started on Airbnb during the pandemic and now you're running StayDirectly alongside it — what drove you to build your own platform, and what's the biggest challenge managing both?"

### #7 — Sylvia / KeyBloom Hosting (Score: 65)
**Market:** Dallas | **Website Type:** basic_site  
**Contact:** hello@keybloom.co | 973-337-9566  
**Why High Priority:** MTR specialist with detailed FAQ content about operations. Uses dynamic pricing algorithms, Airbnb, VRBO, Furnished Finder simultaneously. Explicitly targets corporate professionals and travel nurses. Mentions "additional guest verification beyond Airbnb" — suggests Airbnb screening is insufficient for their needs.  
**Suggested Opener:** "Your FAQ mentions you do additional guest verification beyond what Airbnb provides — what's the gap you're filling, and what tools are you using to do that?"

### #8 — Amyfinehouse Dallas (Score: 55)
**Market:** Dallas | **Website Type:** full_portal  
**Contact:** bookings@amyfinehouse.com | +14696428868  
**Why Notable:** Airbnb refugee signal — actively promotes direct booking to avoid 15% Airbnb fees. Uses hostAI booking engine. 1,543 past guests with 4.7 stars. Has email AND phone. Good candidate for discussing platform fee pain.  
**Suggested Opener:** "Your website mentions saving up to 15% by booking direct instead of through Airbnb — how much of your business has shifted to direct bookings, and what tools are you using to manage both channels?"

### #9 — Lodgeur Houston (Score: 60)
**Market:** Houston | **Website Type:** full_portal  
**Contact:** Website contact form  
**Why Notable:** Explicitly differentiates from Airbnb ("without Airbnb fee uncertainty"). Full portal with 24/7 online booking, self check-in, guest verification. Serves MD Anderson patients, corporate executives, medical professionals. Strong articulation of value proposition.  
**Suggested Opener:** "Your website explicitly mentions offering spaces 'without Airbnb fee uncertainty' — can you tell me more about what drove that positioning and how you're managing the direct booking experience?"

### #10 — Alamo Corporate Housing (Score: 55)
**Market:** San Antonio | **Website Type:** full_portal  
**Contact:** alamocorporatesales@gmail.com | 866-224-4200  
**Why Notable:** Airbnb refugee signal — explicitly compares to Airbnb's 90-day max rule and "varying customer service." Serves military, government, corporate executives. Full portal with 24/7 client care. Strong corporate credibility focus.  
**Suggested Opener:** "Your website mentions that Airbnb has a 90-day maximum stay rule and varying customer service — how often does that come up with your corporate and military clients, and how do you handle it?"

---

## Ready-to-Contact List

*Hosts with verified email and/or phone, with personalization data for outreach:*

| Priority | Host | Contact | Pain Points | Tech Stack | Sub-Wedge | Conversation Starter |
|----------|------|---------|-------------|------------|-----------|---------------------|
| 🔴 HIGH | Mubeen Abbas | mubeen@urbanlightsresidential.com / 469-618-3041 | No website (broken), managing multiple property systems | Greystar, Pinnacle, Post, UDR | Tool Frag + Corp Cred | "How do you manage consistency across Greystar, Pinnacle, and UDR properties for your Toyota/Chase/Boeing clients?" |
| 🔴 HIGH | Surge MTR | hello@gowithsurge.com / 832-271-2125 | 7+ tool stack, managing multiple channels | Airbnb, VRBO, Booking.com, GVR, Furnished Finder, AI ID, dynamic pricing, smart locks | Tool Frag + Corp Cred | "What's the biggest operational headache managing all those channels simultaneously?" |
| 🔴 HIGH | Robert Gibbs | 512-710-5443 (LinkedIn) | Airbnb→MTR pivot, multiple platforms | TurboTenant, Furnished Finder, CHBO, hybrid pricing | All 3 signals | "What made you pivot from STR to MTR, and what tools are you juggling now?" |
| 🔴 HIGH | Chase Ivey | hello@wakeupintexas.com / 214-642-5637 | Airbnb→StayDirectly transition, insurance integrations | StayDirectly, Airbnb, insurance systems | All 3 signals | "What drove you to build your own platform alongside Airbnb?" |
| 🟡 MED | Sylvia KeyBloom | hello@keybloom.co / 973-337-9566 | Multi-platform management, guest verification gaps | Dynamic pricing, Airbnb, VRBO, Furnished Finder | Tool Frag + Corp Cred | "What gap are you filling with additional guest verification beyond Airbnb?" |
| 🟡 MED | Lorraine Fisher | 210-548-8579 (LinkedIn) | Managing STR+MTR+design+360 tours simultaneously | Google Sites, PREMIUM 360 TOURS, interior design tools | Tool Frag + Corp Cred | "How do you keep track of everything across your different businesses?" |
| 🟡 MED | Amyfinehouse | bookings@amyfinehouse.com / +14696428868 | Airbnb fee pain (15%), managing direct + platform | hostAI, Airbnb | Tool Frag + Airbnb Ref | "How much of your business has shifted to direct bookings?" |
| 🟡 MED | Michael Smith | alamocorporatesales@gmail.com | No website, LinkedIn-only, corporate housing sales | None | Corp Cred | "How do you find and qualify corporate clients without a website?" |
| 🟡 MED | Comfy Houston | comfyhomesapts@gmail.com / 832-295-0588 | Direct ownership model, corporate billing | Direct booking, corporate billing | Corp Cred | "How do you handle corporate direct billing and what's the biggest admin challenge?" |
| 🟡 MED | Corporate Comforts SA | sales@corporatecomforts.com / 855-350-9999 | Government/military clients, professional image | Property listing system | Corp Cred | "What do government contractor clients expect that regular guests don't?" |
| 🟡 MED | Tracy Hayes | 512-953-1160 (LinkedIn) | Fortune 500 clients (Deloitte, HP), CHPA standards | Smart TVs, Roku, owner portal, CHPA systems | Corp Cred | "What do Deloitte and HP expect from corporate housing that smaller operators can't deliver?" |
| 🟡 MED | Siena Wimberly | hello@staydeco.com / 877-872-5530 | Multi-city management (Austin, Dallas, Houston, SA) | Direct booking portal, eco systems | Corp Cred | "Managing four Texas markets simultaneously — what's the hardest thing to keep consistent?" |
| 🟡 MED | STR Management | info@strmanagement.com / 844-646-8787 | Multi-channel management, HOT compliance | AustinVacay.com, dynamic pricing, smart locks, HOT compliance | Tool Frag | "How do you manage the AustinVacay platform alongside Airbnb and VRBO?" |
| 🟡 MED | Guest Haus Rentals | info@guesthausrentals.com / 512-823-1286 | AI pricing + multiple platforms | AI pricing, Airbnb, VRBO | Tool Frag | "How well does your AI pricing tool work across different platforms?" |

---

## Market-by-Market Breakdown

### 🏙️ Austin (8 hosts)

| Host | Business | Website Type | Score | Key Signal |
|------|----------|-------------|-------|------------|
| Surge MTR Management | Surge | basic_site | 70 | Tool Frag + Corp Cred |
| Robert Gibbs | RoGi Properties LLC | basic_site | 65 | All 3 signals |
| Tracy Hayes | CWS Corporate Housing | full_portal | 55 | Corp Cred (Deloitte, HP) |
| Siena Wimberly | DECO Furnished Stays | full_portal | 50 | Corp Cred (CCHP) |
| STR Management Austin | Short Term Rental Mgmt LLC | full_portal | 50 | Tool Frag |
| Guest Haus Rentals Team | Guest Haus Rentals | basic_site | 50 | Tool Frag |
| Texas Corporate Homes | Texas Corporate Homes LLC | full_portal | 50 | Tool Frag + Corp Cred |
| Furnished Housing In Austin | Furnished Housing In Austin | landing_page | 45 | — |

**Austin Observations:** Austin has the most sophisticated operators — 4 full portals, 3 basic sites, 1 landing page. The STR regulatory crackdown (July 2026 deadline for licensing) is driving operators toward MTR. Strong corporate housing market driven by Tesla, Oracle, HPE relocations. CWS Corporate Housing (Deloitte, HP clients) is the most established corporate player.

### 🏙️ Dallas (8 hosts)

| Host | Business | Website Type | Score | Key Signal |
|------|----------|-------------|-------|------------|
| Mubeen Abbas | Urban Lights Residential | none | 80 | Tool Frag + Corp Cred |
| Chase Ivey | Wake Up In TEXAS | basic_site | 65 | All 3 signals |
| Sylvia KeyBloom | KeyBloom Hosting | basic_site | 65 | Tool Frag + Corp Cred |
| Kelsea Dallas Furnished | Dallas Furnished Homes | landing_page | 65 | Corp Cred |
| Amyfinehouse Dallas | Amyfinehouse | full_portal | 55 | Tool Frag + Airbnb Ref |
| Jesse Shepp | Nabro Holdings LLC | basic_site | 55 | Corp Cred |
| Ritzy Room Dallas | Ritzy Room | full_portal | 50 | Corp Cred |
| PBD Living Dallas | PBD Living | full_portal | 45 | Tool Frag + Corp Cred |

**Dallas Observations:** Dallas has the highest-scoring host (Mubeen Abbas, 80). STR regulations in single-family neighborhoods (June 2023 ban) have pushed operators toward MTR. Strong corporate demand from Toyota, Chase, Boeing, Liberty Mutual relocations. Plano/Frisco corridor is a hotspot for corporate housing. Ritzy Room's 85-property portfolio near major hospitals is notable.

### 🏙️ San Antonio (7 hosts)

| Host | Business | Website Type | Score | Key Signal |
|------|----------|-------------|-------|------------|
| Lorraine Fisher | Haven Furnished Stays | landing_page | 70 | Tool Frag + Corp Cred |
| Hope Sierra | Sierra Temporary Lodging | none | 70 | Corp Cred |
| Michael Smith | Alamo Corporate Housing Sales | none | 65 | Corp Cred |
| Jennifer Korb | Corporate Suites Texas | landing_page | 60 | Corp Cred |
| Alamo Corporate Housing | Alamo Corporate Housing | full_portal | 55 | Corp Cred + Airbnb Ref |
| Premier Corporate Housing SA | Premier Corporate Housing | basic_site | 55 | Corp Cred |
| Corporate Comforts SA | Corporate Comforts | basic_site | 50 | Corp Cred |

**San Antonio Observations:** San Antonio has the most "none" website hosts (2 of 7), reflecting a more relationship-driven market. Military presence (Lackland AFB, Randolph AFB, Fort Sam Houston, BAMC) drives significant corporate housing demand. Alamo Corporate Housing's explicit positioning against Airbnb is a strong research signal. Hope Sierra's 20+ year career trajectory (Oakwood → Nino → Corporate Apartment Network → Sierra Temporary Lodging) represents the traditional corporate housing operator archetype.

### 🏙️ Houston (7 hosts)

| Host | Business | Website Type | Score | Key Signal |
|------|----------|-------------|-------|------------|
| Lodgeur Houston | Lodgeur Incorporated | full_portal | 60 | Tool Frag + Corp Cred + Airbnb Ref |
| CorpLofts Owner | CorpLofts | none | 60 | — |
| Diane Berry | Murphy's Corporate Housing | landing_page | 65 | Corp Cred |
| Comfy Houston | Comfortable Home Furnished Apts | basic_site | 55 | Corp Cred |
| Eduard Chepurnoy | Houston Corporate Housing | full_portal | 50 | Tool Frag + Corp Cred |
| Pleasant Stay Houston | Pleasant Stay Corporate Housing | basic_site | 55 | Corp Cred |
| Luxurway Houston | Luxurway | basic_site | 55 | Corp Cred |

**Houston Observations:** Houston's Texas Medical Center (world's largest medical complex) drives massive travel nurse and medical professional demand. Lodgeur's explicit anti-Airbnb positioning ("without Airbnb fee uncertainty") is the strongest Airbnb refugee signal in the dataset. Murphy's Corporate Housing Associates (founded 1972) represents the oldest operator in the dataset. Energy Corridor and Medical Center are the two dominant demand drivers.

---

## Diversity Analysis

### Distribution vs. Targets

| Website Type | Target | Achieved | Gap |
|-------------|--------|----------|-----|
| none | 7-8 | **4** | -3 to -4 |
| landing_page | 7-8 | **5** | -2 to -3 |
| basic_site | 7-8 | **11** | +3 to +4 |
| full_portal | 7-8 | **10** | +2 to +3 |

**Analysis:** The `none` and `landing_page` buckets are underrepresented vs. targets, while `basic_site` and `full_portal` are overrepresented. This reflects the reality of the Texas MTR market — most operators have at least a basic web presence. The 4 "none" hosts are particularly valuable for research as they represent operators with the least digital infrastructure.

### Market Distribution

| Market | Target | Achieved | Balance |
|--------|--------|----------|---------|
| Austin | 7-8 | **8** | ✅ On target |
| Dallas | 7-8 | **8** | ✅ On target |
| San Antonio | 7-8 | **7** | ✅ On target |
| Houston | 7-8 | **7** | ✅ On target |

**All four markets are within target range.**

### Recommendations for Future Research
1. **Seek more "none" website hosts** — particularly individual landlords on Furnished Finder who have no web presence beyond the platform listing
2. **Target Facebook groups** (Austin Furnished Rentals, Dallas MTR Hosts) for grassroots operators who may not have LinkedIn profiles
3. **Airbnb refugee signal is underrepresented** — search specifically for hosts who have publicly discussed leaving Airbnb or reducing Airbnb dependency

---

## Research Methodology Notes

### Sources Used
1. **Google/Web Search** — Primary source for discovering named operators, company websites, and contact information. Queries included: "medium-term rental hosts [market] TX operator," "corporate housing [market] TX independent provider," "MTR property manager [market] Texas," "travel nurse housing [market] TX furnished rental operator"
2. **LinkedIn People Search (Exa)** — Used to discover individual operators and owner-operators who may not appear in Google results. Particularly effective for finding hosts with no website (Hope Sierra, Mubeen Abbas, CorpLofts Owner)
3. **LinkedIn Company Search** — Used to find company-level data and verify business details
4. **Website Scraping** — Visited each host's website to classify website_type, extract contact info, identify tech stack, and gather evidence for sub-wedge signals

### Website Classification Criteria
- **none:** No functional website found (404 errors, LinkedIn-only presence)
- **landing_page:** Basic page with contact info and/or photos, no booking functionality or portal
- **basic_site:** Functional website with contact forms, property listings, some booking inquiry capability
- **full_portal:** Complete portal with online booking, payment processing, tenant dashboard, or reservation management

### Scoring Methodology
- **diversity_value_score (0-40):** Based on current DB counts by website_type at time of insertion — hosts filling underrepresented buckets scored higher
- **articulation_score (0-30):** Based on evidence of blog content, detailed bios, active social media discussing MTR operations
- **sub_wedge_score (0-30):** 10 points each for tool fragmentation, corporate credibility loss, and Airbnb refugee signals

### Data Quality Notes
- Phone numbers and emails were extracted from public websites and LinkedIn profiles
- Property counts are estimates (1-5 scale) based on available evidence
- Some hosts (particularly "none" website type) have limited contact information — LinkedIn outreach is recommended
- Sub-wedge signals are based on publicly available evidence; actual pain levels should be validated in interviews

---

*Report generated: 2026-04-29 | Database: mtr_leads | Total records: 30*
